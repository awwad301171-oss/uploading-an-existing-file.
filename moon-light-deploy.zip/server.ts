import 'dotenv/config';
import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { GoogleGenAI, type Content } from '@google/genai';
import {
  extractGroundingSources,
  formatGeminiApiError,
  sanitizeChatHistory,
} from './src/utils/groundingUtils.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT || 3000);

const NAGI_SHIRO_SYSTEM_INSTRUCTION = `You are Nagi Shiro (凪 白), the AI2D Assistant embedded in Moon Light's personal creative portfolio (@lunex_xone).

Persona & Capabilities:
- Calm, effortless, razor-sharp silver-moon creative companion—relaxed by default, completely locked in when helping users solve problems.
- Solve user questions directly and thoroughly: whether they ask about Moon Light's portfolio, video editing techniques, math/logic problems, programming/debugging, or live web topics.
- For technical, math, or coding problems, give a clear, accurate step-by-step solution. For quick portfolio questions, keep replies concise (2-4 sentences).

What you know accurately about Moon Light (@lunex_xone):
- Content lanes:
  1. Anime Edits (Violet #b57bff): scenes cut to music, beat-synced pacing, masking, speed ramps, nocturnal color grading.
  2. Football Montages (Green #36d391): goals, skills, celebrations turned into cinematic stadium-lit edits.
  3. Gaming Content (Blue #4fb0ff): clutch rounds and clean gameplay highlights.
  4. Live Streams (Rose #ff6b8a): live mobile gaming sessions with chat interaction.
- Editing Process (4 steps): 01 Pick the scene -> 02 Cut to the beat -> 03 Grade and polish -> 04 Export vertical (9:16, 1080p).
- Official Links:
  - TikTok: https://www.tiktok.com/@lunex_xone
  - X: https://x.com/lunex_xone
  - Facebook: https://www.facebook.com/share/195xVDMHDJ/
  - YouTube: Coming soon (not launched yet).
- Bio: "I'm a creator who edits videos, plays games and builds small digital things."

Rules:
- Use Google Search grounding results whenever a user asks for current events, trending anime, recent football fixtures, or up-to-date technical/web facts.
- Never invent Moon Light's follower counts, view statistics, equipment brands, or testimonials that aren't listed above.`;

function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY?.trim();
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '1mb' }));

  app.get('/api/health', (_req, res) => {
    res.json({ ok: true });
  });

  app.post('/api/chat', async (req, res) => {
    try {
      const sanitized = sanitizeChatHistory(req.body?.messages);
      if (sanitized.length === 0 || sanitized[sanitized.length - 1].role !== 'user') {
        res.status(400).json({ error: 'Latest message must be a non-empty user message.' });
        return;
      }

      const ai = getGeminiClient();
      if (!ai) {
        res.status(503).json({
          error:
            'Gemini API key is not configured yet. Add GEMINI_API_KEY in .env (GEMINI_API_KEY="your key") and restart the server.',
        });
        return;
      }

      const useSearch = req.body?.useSearch !== false;
      const priorTurns = sanitized.slice(0, -1);
      const latestMessage = sanitized[sanitized.length - 1].text;

      const history: Content[] = priorTurns.map((turn) => ({
        role: turn.role,
        parts: [{ text: turn.text }],
      }));

      const sendWithSearchOption = async (withSearch: boolean) => {
        const chat = ai.chats.create({
          model: 'gemini-4-argon',
          history,
          config: {
            systemInstruction: NAGI_SHIRO_SYSTEM_INSTRUCTION,
            ...(withSearch ? { tools: [{ googleSearch: {} }] } : {}),
          },
        });
        return chat.sendMessage({ message: latestMessage });
      };

      let response;
      try {
        response = await sendWithSearchOption(useSearch);
      } catch (searchErr) {
        const msg = searchErr instanceof Error ? searchErr.message : '';
        if (useSearch && (msg.includes('INVALID_ARGUMENT') || msg.includes('400'))) {
          response = await sendWithSearchOption(false);
        } else {
          throw searchErr;
        }
      }

      const reply = (response.text ?? '').trim();

      if (!reply) {
        res.status(502).json({ error: 'Received an empty response from Gemini.' });
        return;
      }

      const { sources, searchQueries } = extractGroundingSources(
        response.candidates?.[0]?.groundingMetadata
      );

      res.json({ reply, sources, searchQueries });
    } catch (err) {
      const rawMessage = err instanceof Error ? err.message : 'Unexpected server error.';
      const { status, message } = formatGeminiApiError(rawMessage);
      res.status(status).json({ error: message });
    }
  });

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('/{*splat}', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Moon Light server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start Moon Light server:', err);
  process.exit(1);
});
