export type CategorySlug =
  | 'anime-edits'
  | 'football-montages'
  | 'gaming-content'
  | 'live-streams';

export interface ProjectItem {
  slug: CategorySlug;
  tag: string;
  title: string;
  shortDescription: string;
  coverAlt: string;
  accentColor: string;
  accentGlow: string;
  tagline: string;
  description: string[];
  facts: {
    format: string;
    focus: string;
    publishedOn: string;
  };
  tiktokUrl: string;
}

export interface ReelCardItem {
  id: string;
  category: CategorySlug;
  categoryLabel: string;
  title: string;
  duration: string;
  accentColor: string;
  secondaryColor: string;
  pattern: 'slash' | 'pitch' | 'reticle' | 'wave' | 'eclipse' | 'prism';
}

export interface ProcessStep {
  number: string;
  title: string;
  detail: string;
}

export interface AboutDiscipline {
  title: string;
  description: string;
}

export interface SocialLinkItem {
  id: string;
  platform: string;
  handle: string;
  url: string | null;
  statusNote?: string;
  accentColor: string;
}

export const SITE_IDENTITY = {
  brandName: 'Moon Light',
  handle: '@lunex_xone',
  copyright: '© 2026 Moon Light',
  heroHeadlineTop: 'MOON',
  heroHeadlineBottom: 'LIGHT',
  heroSubtitle: 'Anime edits, football montages, gaming content and live streams.',
  primaryCtaLabel: 'See the work',
  secondaryCtaLabel: 'Follow on TikTok',
  tiktokProfileUrl: 'https://www.tiktok.com/@lunex_xone',
  aboutBio:
    "I'm a creator who edits videos, plays games and builds small digital things.",
} as const;

export const MARQUEE_ITEMS = [
  { label: 'Anime Edits', color: '#b57bff' },
  { label: 'Football Montages', color: '#36d391' },
  { label: 'Gaming', color: '#4fb0ff' },
  { label: 'Live Streams', color: '#ff6b8a' },
] as const;

export const PROJECTS: ProjectItem[] = [
  {
    slug: 'anime-edits',
    tag: 'Anime',
    title: 'Anime Edits',
    shortDescription:
      'Scenes cut to music, with timing, color and transitions doing the storytelling.',
    coverAlt:
      'Atmospheric violet-lit anime editing desk frame with nocturnal moon glow and timeline motion',
    accentColor: '#b57bff',
    accentGlow: 'rgba(181, 123, 255, 0.24)',
    tagline: 'Frame-accurate cuts synced to bass drops, silence, and breath.',
    description: [
      'Every anime edit starts by stripping a scene down to its emotional rhythm. Instead of stacking heavy effects over every frame, cuts land directly on percussion hits, vocal swells, and micro-pauses.',
      'Custom speed ramps, masked camera whips, and cool nocturnal color grading pull disparate shots into one cohesive visual sequence built for vertical screens.',
    ],
    facts: {
      format: 'Vertical 9:16 · 1080p',
      focus: 'Beat-synced pacing, masking & color grading',
      publishedOn: 'TikTok (@lunex_xone)',
    },
    tiktokUrl: 'https://www.tiktok.com/@lunex_xone',
  },
  {
    slug: 'football-montages',
    tag: 'Football',
    title: 'Football Montages',
    shortDescription:
      'Goals, skills and celebrations turned into cinematic edits.',
    coverAlt:
      'Night stadium football pitch under emerald floodlights capturing dramatic motion',
    accentColor: '#36d391',
    accentGlow: 'rgba(54, 211, 145, 0.24)',
    tagline: 'Stadium floodlights, touchline speed, and split-second strikes.',
    description: [
      'Football already has natural tension—the run-up, the feint, the split second before the ball leaves the boot. These montages isolate that kinetic arc and amplify it through sound design and camera tracking.',
      'Crowd swells, boot impact SFX, and crisp emerald-and-slate grading turn match highlights into short atmospheric films.',
    ],
    facts: {
      format: 'Vertical 9:16 · 1080p',
      focus: 'Velocity curves, sound design & match cuts',
      publishedOn: 'TikTok (@lunex_xone)',
    },
    tiktokUrl: 'https://www.tiktok.com/@lunex_xone',
  },
  {
    slug: 'gaming-content',
    tag: 'Gaming',
    title: 'Gaming Content',
    shortDescription: 'Highlights and clips from the games I play.',
    coverAlt:
      'Cool electric-blue nocturnal gaming setup with crisp monitor glow and precision peripherals',
    accentColor: '#4fb0ff',
    accentGlow: 'rgba(79, 176, 255, 0.24)',
    tagline: 'Sharp mechanics, clutch rounds, and clean visual pacing.',
    description: [
      'Captured straight from late-night sessions, these clips focus on clean gameplay readability without screen clutter. Key moments are tightened so the viewer feels the split-second read behind every play.',
      'Subtle HUD emphasis, crisp audio mixing, and kinetic transitions keep momentum locked from the opening frame to the final round.',
    ],
    facts: {
      format: 'Vertical 9:16 · 1080p',
      focus: 'Clutch highlights, pacing & audio punch',
      publishedOn: 'TikTok (@lunex_xone)',
    },
    tiktokUrl: 'https://www.tiktok.com/@lunex_xone',
  },
  {
    slug: 'live-streams',
    tag: 'Live',
    title: 'Live Streams',
    shortDescription: 'Mobile gaming, live, with the chat in the room.',
    coverAlt:
      'Late-night mobile gaming broadcast setup bathed in rose-crimson and indigo studio lighting',
    accentColor: '#ff6b8a',
    accentGlow: 'rgba(255, 107, 138, 0.24)',
    tagline: 'Unfiltered mobile matches, real-time reactions, and community sessions.',
    description: [
      'Live streams strip away the timeline and put everything in real time. Mobile gaming sessions unfold alongside live chat—calling plays, reacting to upsets, and testing new setups together.',
      'Memorable moments from the stream feed directly back into edited highlights, keeping the live room and short-form archive connected.',
    ],
    facts: {
      format: 'Live Mobile Portrait · Interactive Chat',
      focus: 'Real-time mobile gaming & community play',
      publishedOn: 'TikTok LIVE (@lunex_xone)',
    },
    tiktokUrl: 'https://www.tiktok.com/@lunex_xone',
  },
];

export const REELS_SHOWCASE: ReelCardItem[] = [
  {
    id: 'reel-1',
    category: 'anime-edits',
    categoryLabel: 'Anime',
    title: 'Midnight Eclipse Cut',
    duration: '00:24',
    accentColor: '#b57bff',
    secondaryColor: '#7482ff',
    pattern: 'slash',
  },
  {
    id: 'reel-2',
    category: 'football-montages',
    categoryLabel: 'Football',
    title: 'Floodlight Counter',
    duration: '00:31',
    accentColor: '#36d391',
    secondaryColor: '#7482ff',
    pattern: 'pitch',
  },
  {
    id: 'reel-3',
    category: 'gaming-content',
    categoryLabel: 'Gaming',
    title: 'Zero Ping Clutch',
    duration: '00:19',
    accentColor: '#4fb0ff',
    secondaryColor: '#cfd8ff',
    pattern: 'reticle',
  },
  {
    id: 'reel-4',
    category: 'live-streams',
    categoryLabel: 'Live',
    title: 'Late Night Ranked',
    duration: '00:42',
    accentColor: '#ff6b8a',
    secondaryColor: '#b57bff',
    pattern: 'wave',
  },
  {
    id: 'reel-5',
    category: 'anime-edits',
    categoryLabel: 'Anime',
    title: 'Lunar Horizon Flow',
    duration: '00:28',
    accentColor: '#b57bff',
    secondaryColor: '#cfd8ff',
    pattern: 'eclipse',
  },
  {
    id: 'reel-6',
    category: 'football-montages',
    categoryLabel: 'Football',
    title: 'Last Minute Strike',
    duration: '00:26',
    accentColor: '#36d391',
    secondaryColor: '#4fb0ff',
    pattern: 'prism',
  },
];

export const PROCESS_STEPS: ProcessStep[] = [
  {
    number: '01',
    title: 'Pick the scene',
    detail: 'Isolate the frame, match moment, or gameplay play that holds natural tension.',
  },
  {
    number: '02',
    title: 'Cut to the beat',
    detail: 'Lock transitions, speed ramps, and motion to the exact pulse of the track.',
  },
  {
    number: '03',
    title: 'Grade and polish',
    detail: 'Shape contrast, nocturnal color tone, and crisp layered sound effects.',
  },
  {
    number: '04',
    title: 'Export vertical',
    detail: 'Mastered clean in 9:16, 1080p for sharp playback on mobile screens.',
  },
];

export const ABOUT_DISCIPLINES: AboutDiscipline[] = [
  {
    title: 'Gaming',
    description: 'Competitive mobile matches, clutch rounds, and live community sessions.',
  },
  {
    title: 'Video edits',
    description: 'Beat-driven anime sequences and high-tempo football montages.',
  },
  {
    title: 'Technology',
    description: 'Clean interfaces, editing workflows, and small digital experiments.',
  },
  {
    title: 'Creativity',
    description: 'Turning raw clips, rhythm, and night-sky atmosphere into story.',
  },
];

export const SOCIAL_LINKS: SocialLinkItem[] = [
  {
    id: 'tiktok',
    platform: 'TikTok',
    handle: '@lunex_xone',
    url: 'https://www.tiktok.com/@lunex_xone',
    accentColor: '#7482ff',
  },
  {
    id: 'x',
    platform: 'X',
    handle: '@lunex_xone',
    url: 'https://x.com/lunex_xone',
    accentColor: '#cfd8ff',
  },
  {
    id: 'facebook',
    platform: 'Facebook',
    handle: 'Moon Light',
    url: 'https://www.facebook.com/share/195xVDMHDJ/',
    accentColor: '#4fb0ff',
  },
  {
    id: 'youtube',
    platform: 'YouTube',
    handle: 'Coming soon',
    url: null,
    statusNote: 'Coming soon',
    accentColor: '#9298b0',
  },
];
