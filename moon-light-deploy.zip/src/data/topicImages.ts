import type { CategorySlug } from './portfolioData';
import animeEditsCover from '../assets/images/topic_anime_edits_1794779246535.jpg';
import footballMontagesCover from '../assets/images/topic_football_montages_1794779247522.jpg';
import gamingContentCover from '../assets/images/topic_gaming_content_1794779247784.jpg';
import liveStreamsCover from '../assets/images/topic_live_streams_1794779248040.jpg';

export const TOPIC_COVER_IMAGES: Record<CategorySlug, string> = {
  'anime-edits': animeEditsCover,
  'football-montages': footballMontagesCover,
  'gaming-content': gamingContentCover,
  'live-streams': liveStreamsCover,
};
