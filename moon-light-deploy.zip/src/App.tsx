import { lazy, Suspense, useCallback, useEffect, useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { PROJECTS, type CategorySlug } from './data/portfolioData';
import {
  useIsTouchDevice,
  usePrefersReducedMotion,
  useTabVisible,
} from './hooks/useMotionEnvironment';
import {
  buildProjectHash,
  computeScrollProgress,
  parseProjectHash,
  pickActiveVisibleSlug,
  resolveScrollAccentColor,
  type VisibleSectionRect,
} from './utils/moonMath';
import { IntroSequence } from './components/IntroSequence';
import { CustomCursor } from './components/CustomCursor';
import { ScrollProgressBar } from './components/ScrollProgressBar';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { MarqueeTicker } from './components/MarqueeTicker';
import { WorkGrid } from './components/WorkGrid';
import { ReelsShowcase } from './components/ReelsShowcase';
import { ProcessSection } from './components/ProcessSection';
import { AboutSection } from './components/AboutSection';
import { ContactSection } from './components/ContactSection';
import { ProjectPage } from './components/ProjectPage';
import { MoonPhaseWidget } from './components/MoonPhaseWidget';
import { MoonChatWidget } from './components/MoonChatWidget';
import { Footer } from './components/Footer';

const LunarStudio3D = lazy(() =>
  import('./components/LunarStudio3D').then((m) => ({ default: m.LunarStudio3D }))
);

export default function App() {
  const reducedMotion = usePrefersReducedMotion();
  const tabVisible = useTabVisible();
  const isTouchDevice = useIsTouchDevice();

  const skipIntroInitial = useMemo(() => {
    if (typeof window === 'undefined') return false;
    const params = new URLSearchParams(window.location.search);
    return params.get('autostart') === '1';
  }, []);

  const [introDone, setIntroDone] = useState(skipIntroInitial || reducedMotion);
  const [activeSlug, setActiveSlug] = useState<CategorySlug | null>(() => {
    if (typeof window === 'undefined') return null;
    return parseProjectHash(window.location.hash);
  });
  const [scrollProgress, setScrollProgress] = useState(0);
  const [visibleProjectSlug, setVisibleProjectSlug] = useState<CategorySlug | null>(null);

  // Sync URL hash changes (browser back/forward & direct links)
  useEffect(() => {
    const onHashChange = () => {
      const slug = parseProjectHash(window.location.hash);
      setActiveSlug(slug);
      if (slug) {
        window.scrollTo({ top: 0, behavior: 'auto' });
      }
    };
    window.addEventListener('hashchange', onHashChange);
    return () => window.removeEventListener('hashchange', onHashChange);
  }, []);

  // Track scroll depth and visible project section accent color
  useEffect(() => {
    let rafId = 0;
    const updateScroll = () => {
      const progress = computeScrollProgress(
        window.scrollY,
        document.documentElement.scrollHeight,
        window.innerHeight
      );
      setScrollProgress(progress);

      if (!activeSlug) {
        const cards = document.querySelectorAll<HTMLElement>('[data-project-slug]');
        const rects: VisibleSectionRect[] = [];
        cards.forEach((el) => {
          const slug = el.dataset.projectSlug as CategorySlug | undefined;
          if (!slug) return;
          const r = el.getBoundingClientRect();
          rects.push({ slug, top: r.top, bottom: r.bottom });
        });
        setVisibleProjectSlug(pickActiveVisibleSlug(rects, window.innerHeight));
      } else {
        setVisibleProjectSlug(null);
      }

      rafId = 0;
    };

    const onScroll = () => {
      if (!rafId) {
        rafId = window.requestAnimationFrame(updateScroll);
      }
    };

    updateScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', updateScroll, { passive: true });
    return () => {
      if (rafId) window.cancelAnimationFrame(rafId);
      window.removeEventListener('scroll', onScroll);
      window.removeEventListener('resize', updateScroll);
    };
  }, [activeSlug]);

  const handleIntroComplete = useCallback(() => {
    setIntroDone(true);
  }, []);

  const openProject = useCallback(
    (slug: CategorySlug) => {
      const nextHash = buildProjectHash(slug);
      if (window.location.hash !== nextHash) {
        window.location.hash = nextHash;
      } else {
        setActiveSlug(slug);
      }
      window.scrollTo({ top: 0, behavior: 'auto' });
    },
    []
  );

  const navigateHomeSection = useCallback(
    (sectionId: string) => {
      const scrollToTarget = () => {
        const el = document.getElementById(sectionId);
        if (el) {
          el.scrollIntoView({ behavior: reducedMotion ? 'auto' : 'smooth' });
        }
      };

      if (activeSlug) {
        window.history.pushState(null, '', `#${sectionId}`);
        setActiveSlug(null);
        window.setTimeout(scrollToTarget, 60);
      } else {
        scrollToTarget();
      }
    },
    [activeSlug, reducedMotion]
  );

  const navigateHomeTop = useCallback(() => {
    if (activeSlug) {
      window.history.pushState(null, '', '#top');
      setActiveSlug(null);
    }
    window.scrollTo({ top: 0, behavior: reducedMotion ? 'auto' : 'smooth' });
  }, [activeSlug, reducedMotion]);

  const activeProject = useMemo(
    () => PROJECTS.find((p) => p.slug === activeSlug) ?? null,
    [activeSlug]
  );

  const scrollAccentColor = useMemo(
    () => resolveScrollAccentColor(activeSlug, visibleProjectSlug),
    [activeSlug, visibleProjectSlug]
  );

  return (
    <div
      data-state={introDone ? (activeProject ? 'project' : 'home') : 'intro'}
      className="relative min-h-screen bg-[#090a0f] text-[#e9ecf8]"
    >
      {/* Top fixed scroll progress indicator with section-aware accent */}
      <ScrollProgressBar
        progress={scrollProgress}
        accentColor={scrollAccentColor}
        reducedMotion={reducedMotion}
      />

      {/* Opening sequence */}
      <IntroSequence
        skipImmediately={skipIntroInitial || reducedMotion}
        onComplete={handleIntroComplete}
      />

      {/* Desktop custom cursor */}
      <CustomCursor disabled={isTouchDevice || reducedMotion} />

      {/* Subtle global film grain & scanlines */}
      <div
        aria-hidden="true"
        className="film-grain scanlines pointer-events-none fixed inset-0 z-40 opacity-65"
      />

      {/* Sticky minimal header */}
      <Header
        onNavigateSection={navigateHomeSection}
        onNavigateHome={navigateHomeTop}
      />

      {/* Main page content with smooth transitions */}
      <main id="main-content">
        <AnimatePresence mode="wait">
          {activeProject ? (
            <motion.div
              key={activeProject.slug}
              initial={reducedMotion ? false : { opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={reducedMotion ? undefined : { opacity: 0, y: -8 }}
              transition={{ duration: reducedMotion ? 0 : 0.22, ease: [0.16, 1, 0.3, 1] }}
            >
              <ProjectPage
                project={activeProject}
                onBack={() => navigateHomeSection('work')}
                onSelectProject={openProject}
              />
            </motion.div>
          ) : (
            <motion.div
              key="home-view"
              initial={reducedMotion ? false : { opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={reducedMotion ? undefined : { opacity: 0, y: -8 }}
              transition={{ duration: reducedMotion ? 0 : 0.22, ease: [0.16, 1, 0.3, 1] }}
            >
              <Hero
                reducedMotion={reducedMotion}
                tabVisible={tabVisible}
                onSeeWork={() => navigateHomeSection('work')}
              />
              <MarqueeTicker reducedMotion={reducedMotion} tabVisible={tabVisible} />
              <WorkGrid onSelectProject={openProject} />
              <ReelsShowcase />
              <Suspense
                fallback={
                  <section
                    id="studio-3d"
                    className="border-b border-[#20233a] bg-[#090a0f] py-20 sm:py-28"
                  >
                    <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
                      <div className="h-[460px] sm:h-[560px] border border-[#20233a] bg-[#10121a]" />
                    </div>
                  </section>
                }
              >
                <LunarStudio3D reducedMotion={reducedMotion} tabVisible={tabVisible} />
              </Suspense>
              <ProcessSection reducedMotion={reducedMotion} />
              <AboutSection />
              <ContactSection />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      <Footer onBackToTop={navigateHomeTop} />

      {/* Bottom-left Nagi Shiro AI2D Assistant */}
      <MoonChatWidget reducedMotion={reducedMotion} />

      {/* Scroll-driven bottom-right corner moon phase widget */}
      <MoonPhaseWidget scrollProgress={scrollProgress} />
    </div>
  );
}

