import test from 'node:test';
import assert from 'node:assert/strict';
import {
  extractGroundingSources,
  formatGeminiApiError,
  getNagiExpressionMeta,
  sanitizeChatHistory,
} from './groundingUtils';

test('extractGroundingSources extracts, deduplicates, and validates web chunks', () => {
  const metadata = {
    webSearchQueries: ['2026 anime hits', '2026 Anime Hits', '   ', 'football edit transitions'],
    groundingChunks: [
      { web: { uri: 'https://www.example.com/anime-news', title: 'Anime News Network' } },
      { web: { uri: 'https://www.example.com/anime-news', title: 'Duplicate URL' } },
      { web: { uri: 'javascript:alert(1)', title: 'Bad Protocol' } },
      { web: { uri: 'https://moonlight.studio/guide' } },
      { web: { uri: 'not-a-valid-url', title: 'Invalid' } },
    ],
  };

  const result = extractGroundingSources(metadata);
  assert.equal(result.sources.length, 2);
  assert.deepEqual(result.sources[0], {
    title: 'Anime News Network',
    url: 'https://www.example.com/anime-news',
    domain: 'example.com',
  });
  assert.deepEqual(result.sources[1], {
    title: 'moonlight.studio',
    url: 'https://moonlight.studio/guide',
    domain: 'moonlight.studio',
  });
  assert.deepEqual(result.searchQueries, ['2026 anime hits', 'football edit transitions']);
});

test('extractGroundingSources handles missing or malformed metadata gracefully', () => {
  assert.deepEqual(extractGroundingSources(null), { sources: [], searchQueries: [] });
  assert.deepEqual(extractGroundingSources({}), { sources: [], searchQueries: [] });
});

test('sanitizeChatHistory trims messages, rejects invalid entries, and ensures alternating turns', () => {
  const cleaned = sanitizeChatHistory([
    { role: 'model', text: 'Synthetic client greeting' },
    { role: 'user', text: 'Failed prior turn' },
    { role: 'user', text: '   How do you time anime edits?   ' },
    { role: 'invalid', text: 'Should drop' },
    { role: 'model', text: '   ' },
    { role: 'model', text: 'Lock cuts directly to beat transients.' },
  ]);

  assert.deepEqual(cleaned, [
    { role: 'user', text: 'How do you time anime edits?' },
    { role: 'model', text: 'Lock cuts directly to beat transients.' },
  ]);
});

test('getNagiExpressionMeta returns readable labels and Moon Light accents', () => {
  assert.deepEqual(getNagiExpressionMeta('searching'), {
    label: 'Searching Web',
    accent: '#4fb0ff',
  });
  assert.deepEqual(getNagiExpressionMeta('calm'), {
    label: 'Calm',
    accent: '#7482ff',
  });
});

test('formatGeminiApiError extracts nested JSON errors and adds Settings > Secrets guidance on 403', () => {
  const res = formatGeminiApiError(
    'Got status: 403 Forbidden. {"error":{"code":403,"message":"Your API key was reported as leaked. Please use another API key.","status":"PERMISSION_DENIED"}}'
  );
  assert.equal(res.status, 403);
  assert.match(res.message, /reported as leaked/i);
  assert.match(res.message, /Settings > Secrets/);
});
