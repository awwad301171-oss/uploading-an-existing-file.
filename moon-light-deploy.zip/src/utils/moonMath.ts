import type { CategorySlug, ProjectItem } from '../data/portfolioData';

export type MoonPhaseName =
  | 'New Moon'
  | 'Waxing Crescent'
  | 'First Quarter'
  | 'Waxing Gibbous'
  | 'Full Moon';

export interface MoonPhaseState {
  progress: number;
  illumination: number;
  phaseName: MoonPhaseName;
}

const VALID_SLUGS: ReadonlyArray<CategorySlug> = [
  'anime-edits',
  'football-montages',
  'gaming-content',
  'live-streams',
];

export function clamp01(value: number): number {
  if (!Number.isFinite(value)) return 0;
  if (value <= 0) return 0;
  if (value >= 1) return 1;
  return value;
}

export function computeScrollProgress(
  scrollY: number,
  scrollHeight: number,
  innerHeight: number
): number {
  const maxScroll = scrollHeight - innerHeight;
  if (maxScroll <= 0 || !Number.isFinite(scrollY)) return 0;
  return clamp01(scrollY / maxScroll);
}

export function calculateMoonPhase(scrollProgress: number): MoonPhaseState {
  const progress = clamp01(scrollProgress);

  let phaseName: MoonPhaseName;
  if (progress < 0.12) {
    phaseName = 'New Moon';
  } else if (progress < 0.38) {
    phaseName = 'Waxing Crescent';
  } else if (progress < 0.62) {
    phaseName = 'First Quarter';
  } else if (progress < 0.88) {
    phaseName = 'Waxing Gibbous';
  } else {
    phaseName = 'Full Moon';
  }

  // Smoothly eased illumination curve from 0.04 (subtle rim on New Moon) to 1.0 (Full Moon)
  const illumination = Number((0.04 + progress * 0.96).toFixed(4));

  return {
    progress,
    illumination,
    phaseName,
  };
}

export function getMoonLitPath(illumination: number, cx = 12, cy = 12, r = 10): string {
  const clamped = clamp01(illumination);
  if (clamped >= 0.99) {
    return `M ${cx} ${cy - r} A ${r} ${r} 0 1 1 ${cx} ${cy + r} A ${r} ${r} 0 1 1 ${cx} ${cy - r} Z`;
  }
  const k = clamped * 2 - 1; // -1 (new) -> 0 (first quarter) -> +1 (full)
  const rx = Math.max(0.01, Math.abs(k) * r);
  // Outer right limb sweeps clockwise (1) from top to bottom.
  // Inner terminator sweeps counter-clockwise (0) for crescent (k < 0), clockwise (1) for gibbous (k >= 0).
  const sweepTerminator = k >= 0 ? 1 : 0;
  return `M ${cx} ${cy - r} A ${r} ${r} 0 1 1 ${cx} ${cy + r} A ${rx.toFixed(2)} ${r} 0 0 ${sweepTerminator} ${cx} ${cy - r} Z`;
}

export function parseProjectHash(hash: string): CategorySlug | null {
  const cleaned = hash.replace(/^#\/?/, '').trim();
  if (!cleaned.startsWith('project/')) {
    return null;
  }
  const slug = cleaned.slice('project/'.length).replace(/\/+$/, '');
  if ((VALID_SLUGS as ReadonlyArray<string>).includes(slug)) {
    return slug as CategorySlug;
  }
  return null;
}

export function buildProjectHash(slug: CategorySlug): string {
  return `#/project/${slug}`;
}

export function getNextProject(
  currentSlug: CategorySlug,
  projects: readonly ProjectItem[]
): ProjectItem {
  if (projects.length === 0) {
    throw new Error('Projects list cannot be empty');
  }
  const index = projects.findIndex((p) => p.slug === currentSlug);
  if (index === -1) {
    return projects[0];
  }
  return projects[(index + 1) % projects.length];
}

export function clampParallax(
  normalizedX: number,
  normalizedY: number,
  maxOffset = 22
): { x: number; y: number } {
  const clampedX = Math.max(-1, Math.min(1, Number.isFinite(normalizedX) ? normalizedX : 0));
  const clampedY = Math.max(-1, Math.min(1, Number.isFinite(normalizedY) ? normalizedY : 0));
  return {
    x: Number((clampedX * maxOffset).toFixed(2)),
    y: Number((clampedY * maxOffset).toFixed(2)),
  };
}

export const DEFAULT_SCROLL_ACCENT = '#7482ff';

const CATEGORY_ACCENT_COLORS: Record<CategorySlug, string> = {
  'anime-edits': '#b57bff',
  'football-montages': '#36d391',
  'gaming-content': '#4fb0ff',
  'live-streams': '#ff6b8a',
};

export function resolveScrollAccentColor(
  activeProjectSlug: CategorySlug | null,
  visibleProjectSlug: CategorySlug | null
): string {
  const slug = activeProjectSlug ?? visibleProjectSlug;
  if (!slug) {
    return DEFAULT_SCROLL_ACCENT;
  }
  return CATEGORY_ACCENT_COLORS[slug] ?? DEFAULT_SCROLL_ACCENT;
}

export interface VisibleSectionRect {
  slug: CategorySlug;
  top: number;
  bottom: number;
}

export function pickActiveVisibleSlug(
  rects: ReadonlyArray<VisibleSectionRect>,
  viewportHeight: number
): CategorySlug | null {
  if (rects.length === 0 || viewportHeight <= 0) {
    return null;
  }

  const focusY = viewportHeight * 0.45;
  let bestSlug: CategorySlug | null = null;
  let bestScore = Number.POSITIVE_INFINITY;

  for (const rect of rects) {
    const visibleHeight = Math.min(rect.bottom, viewportHeight) - Math.max(rect.top, 0);
    if (visibleHeight <= 24) {
      continue;
    }
    const center = (rect.top + rect.bottom) * 0.5;
    const distance = Math.abs(center - focusY);
    if (distance < bestScore) {
      bestScore = distance;
      bestSlug = rect.slug;
    }
  }

  return bestSlug;
}

