import test from 'node:test';
import assert from 'node:assert/strict';
import {
  buildProjectHash,
  calculateMoonPhase,
  clampParallax,
  computeScrollProgress,
  DEFAULT_SCROLL_ACCENT,
  getMoonLitPath,
  getNextProject,
  parseProjectHash,
  pickActiveVisibleSlug,
  resolveScrollAccentColor,
} from './moonMath';
import { PROJECTS } from '../data/portfolioData';

test('getMoonLitPath uses counter-clockwise terminator for crescent and clockwise for gibbous', () => {
  const newMoonPath = getMoonLitPath(0.04);
  assert.ok(newMoonPath.includes('0 0 0 12 2'), `Expected crescent sweep 0, got: ${newMoonPath}`);

  const gibbousPath = getMoonLitPath(0.75);
  assert.ok(gibbousPath.includes('0 0 1 12 2'), `Expected gibbous sweep 1, got: ${gibbousPath}`);

  const fullPath = getMoonLitPath(1);
  assert.ok(fullPath.includes('A 10 10 0 1 1 12 2 Z'), `Expected full circle path, got: ${fullPath}`);
});

test('calculateMoonPhase waxes monotonically from New Moon to Full Moon', () => {
  const newMoon = calculateMoonPhase(0);
  assert.equal(newMoon.phaseName, 'New Moon');
  assert.equal(newMoon.progress, 0);

  const crescent = calculateMoonPhase(0.25);
  assert.equal(crescent.phaseName, 'Waxing Crescent');

  const quarter = calculateMoonPhase(0.5);
  assert.equal(quarter.phaseName, 'First Quarter');

  const gibbous = calculateMoonPhase(0.75);
  assert.equal(gibbous.phaseName, 'Waxing Gibbous');

  const fullMoon = calculateMoonPhase(1);
  assert.equal(fullMoon.phaseName, 'Full Moon');
  assert.equal(fullMoon.illumination, 1);

  assert.ok(newMoon.illumination < crescent.illumination);
  assert.ok(crescent.illumination < quarter.illumination);
  assert.ok(quarter.illumination < gibbous.illumination);
  assert.ok(gibbous.illumination < fullMoon.illumination);
});

test('calculateMoonPhase clamps out-of-range scroll progress safely', () => {
  assert.equal(calculateMoonPhase(-0.5).phaseName, 'New Moon');
  assert.equal(calculateMoonPhase(1.8).phaseName, 'Full Moon');
  assert.equal(calculateMoonPhase(Number.NaN).phaseName, 'New Moon');
});

test('computeScrollProgress handles edge document heights cleanly', () => {
  assert.equal(computeScrollProgress(0, 2000, 900), 0);
  assert.equal(computeScrollProgress(550, 2000, 900), 0.5);
  assert.equal(computeScrollProgress(1100, 2000, 900), 1);
  assert.equal(computeScrollProgress(100, 800, 900), 0);
});

test('parseProjectHash and buildProjectHash round-trip valid categories and reject invalid hashes', () => {
  for (const project of PROJECTS) {
    const hash = buildProjectHash(project.slug);
    assert.equal(parseProjectHash(hash), project.slug);
  }
  assert.equal(parseProjectHash('#/project/anime-edits/'), 'anime-edits');
  assert.equal(parseProjectHash('#work'), null);
  assert.equal(parseProjectHash('#/project/unknown-slug'), null);
  assert.equal(parseProjectHash(''), null);
});

test('getNextProject cycles through all four categories cleanly', () => {
  assert.equal(getNextProject('anime-edits', PROJECTS).slug, 'football-montages');
  assert.equal(getNextProject('football-montages', PROJECTS).slug, 'gaming-content');
  assert.equal(getNextProject('gaming-content', PROJECTS).slug, 'live-streams');
  assert.equal(getNextProject('live-streams', PROJECTS).slug, 'anime-edits');
});

test('clampParallax keeps cursor offsets within bounded range', () => {
  assert.deepEqual(clampParallax(0, 0, 20), { x: 0, y: 0 });
  assert.deepEqual(clampParallax(2.5, -3, 20), { x: 20, y: -20 });
  assert.deepEqual(clampParallax(0.5, -0.25, 20), { x: 10, y: -5 });
});

test('resolveScrollAccentColor prioritizes active project then visible card then default indigo', () => {
  assert.equal(resolveScrollAccentColor(null, null), DEFAULT_SCROLL_ACCENT);
  assert.equal(resolveScrollAccentColor(null, 'anime-edits'), '#b57bff');
  assert.equal(resolveScrollAccentColor(null, 'football-montages'), '#36d391');
  assert.equal(resolveScrollAccentColor(null, 'gaming-content'), '#4fb0ff');
  assert.equal(resolveScrollAccentColor(null, 'live-streams'), '#ff6b8a');
  assert.equal(resolveScrollAccentColor('live-streams', 'anime-edits'), '#ff6b8a');
});

test('pickActiveVisibleSlug chooses the visible card closest to the viewport focus line', () => {
  const viewportHeight = 900;
  assert.equal(pickActiveVisibleSlug([], viewportHeight), null);

  // Cards scrolled completely off-screen should return null
  assert.equal(
    pickActiveVisibleSlug(
      [
        { slug: 'anime-edits', top: -600, bottom: -100 },
        { slug: 'live-streams', top: 1000, bottom: 1500 },
      ],
      viewportHeight
    ),
    null
  );

  // Card centered near 45% viewport height wins
  assert.equal(
    pickActiveVisibleSlug(
      [
        { slug: 'anime-edits', top: -200, bottom: 180 },
        { slug: 'football-montages', top: 200, bottom: 620 },
        { slug: 'gaming-content', top: 700, bottom: 1120 },
      ],
      viewportHeight
    ),
    'football-montages'
  );
});

