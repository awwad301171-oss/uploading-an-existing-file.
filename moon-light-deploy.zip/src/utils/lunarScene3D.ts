import * as THREE from 'three';
import type { CategorySlug } from '../data/portfolioData';

export type StudioCameraPresetId = 'overview' | 'rig' | 'closeup';
export type StudioMoodId = 'indigo' | CategorySlug;

export interface StudioCameraPreset {
  id: StudioCameraPresetId;
  label: string;
  position: [number, number, number];
  target: [number, number, number];
}

export interface StudioMoodPreset {
  id: StudioMoodId;
  label: string;
  accentHex: string;
  secondaryHex: string;
  rimIntensity: number;
}

export const STUDIO_CAMERA_PRESETS: ReadonlyArray<StudioCameraPreset> = [
  {
    id: 'overview',
    label: 'Overview',
    position: [4.2, 2.75, 5.4],
    target: [0, 1.55, 0],
  },
  {
    id: 'rig',
    label: 'Orbital Rig',
    position: [-4.6, 3.2, 4.1],
    target: [0, 1.65, 0],
  },
  {
    id: 'closeup',
    label: 'Lunar Core',
    position: [1.85, 2.0, 3.2],
    target: [0, 1.78, 0],
  },
];

export const STUDIO_MOODS: ReadonlyArray<StudioMoodPreset> = [
  {
    id: 'indigo',
    label: 'Indigo',
    accentHex: '#7482ff',
    secondaryHex: '#4fb0ff',
    rimIntensity: 7.0,
  },
  {
    id: 'anime-edits',
    label: 'Anime',
    accentHex: '#b57bff',
    secondaryHex: '#ff6b8a',
    rimIntensity: 7.5,
  },
  {
    id: 'football-montages',
    label: 'Football',
    accentHex: '#36d391',
    secondaryHex: '#4fb0ff',
    rimIntensity: 7.2,
  },
  {
    id: 'gaming-content',
    label: 'Gaming',
    accentHex: '#4fb0ff',
    secondaryHex: '#7482ff',
    rimIntensity: 7.5,
  },
  {
    id: 'live-streams',
    label: 'Live',
    accentHex: '#ff6b8a',
    secondaryHex: '#b57bff',
    rimIntensity: 7.8,
  },
];

function seededNoise(seed: number): () => number {
  let state = seed >>> 0;
  return () => {
    state = (1664525 * state + 1013904223) >>> 0;
    return state / 0xffffffff;
  };
}

export interface LunarTextures {
  albedo: THREE.CanvasTexture;
  bump: THREE.CanvasTexture;
  roughness: THREE.CanvasTexture;
  emissive: THREE.CanvasTexture;
  shadowDisc: THREE.CanvasTexture;
  dispose: () => void;
}

export function createLunarProceduralTextures(maxAnisotropy: number): LunarTextures {
  const width = 512;
  const height = 256;

  const albedoCanvas = document.createElement('canvas');
  albedoCanvas.width = width;
  albedoCanvas.height = height;
  const albedoCtx = albedoCanvas.getContext('2d')!;

  const bumpCanvas = document.createElement('canvas');
  bumpCanvas.width = width;
  bumpCanvas.height = height;
  const bumpCtx = bumpCanvas.getContext('2d')!;

  const roughCanvas = document.createElement('canvas');
  roughCanvas.width = width;
  roughCanvas.height = height;
  const roughCtx = roughCanvas.getContext('2d')!;

  const emissiveCanvas = document.createElement('canvas');
  emissiveCanvas.width = width;
  emissiveCanvas.height = height;
  const emissiveCtx = emissiveCanvas.getContext('2d')!;

  // Modern sculpted deep-obsidian lunar gradient base for maximum neon contrast
  const baseGrad = albedoCtx.createLinearGradient(0, 0, 0, height);
  baseGrad.addColorStop(0, '#181e36');
  baseGrad.addColorStop(0.35, '#0c0f1d');
  baseGrad.addColorStop(0.5, '#12182c');
  baseGrad.addColorStop(0.65, '#0c0f1d');
  baseGrad.addColorStop(1, '#181e36');
  albedoCtx.fillStyle = baseGrad;
  albedoCtx.fillRect(0, 0, width, height);

  bumpCtx.fillStyle = '#808080';
  bumpCtx.fillRect(0, 0, width, height);

  // Satin matte obsidian panels contrasted against brushed silver seams
  roughCtx.fillStyle = '#5c5c5c';
  roughCtx.fillRect(0, 0, width, height);

  emissiveCtx.fillStyle = '#000000';
  emissiveCtx.fillRect(0, 0, width, height);

  const rand = seededNoise(202611);

  // Subtle modern topographic bands (abstracted lunar maria ribbons)
  for (let i = 0; i < 18; i++) {
    const cx = rand() * width;
    const cy = 48 + rand() * (height - 96);
    const rx = 60 + rand() * 140;
    const ry = 22 + rand() * 54;

    const grad = albedoCtx.createRadialGradient(cx, cy, 4, cx, cy, rx);
    grad.addColorStop(0, i % 2 === 0 ? 'rgba(116, 130, 255, 0.22)' : 'rgba(79, 176, 255, 0.16)');
    grad.addColorStop(0.6, 'rgba(30, 36, 62, 0.45)');
    grad.addColorStop(1, 'rgba(20, 24, 42, 0)');
    albedoCtx.fillStyle = grad;
    albedoCtx.beginPath();
    albedoCtx.ellipse(cx, cy, rx, ry, rand() * 0.4, 0, Math.PI * 2);
    albedoCtx.fill();

    const rGrad = roughCtx.createRadialGradient(cx, cy, 4, cx, cy, rx);
    rGrad.addColorStop(0, 'rgba(195, 195, 195, 0.35)');
    rGrad.addColorStop(1, 'rgba(195, 195, 195, 0)');
    roughCtx.fillStyle = rGrad;
    roughCtx.beginPath();
    roughCtx.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2);
    roughCtx.fill();
  }

  // Modern architectural hexagonal/concentric lunar terrain cells
  for (let i = 0; i < 28; i++) {
    const cx = rand() * width;
    const cy = 56 + rand() * (height - 112);
    const r = 10 + rand() * 26;

    // Sharp terraced rim in bump + sleek highlight in albedo
    bumpCtx.strokeStyle = '#d8d8d8';
    bumpCtx.lineWidth = 2;
    bumpCtx.beginPath();
    bumpCtx.arc(cx, cy, r, 0, Math.PI * 2);
    bumpCtx.stroke();

    bumpCtx.fillStyle = 'rgba(42, 42, 42, 0.55)';
    bumpCtx.beginPath();
    bumpCtx.arc(cx, cy, r * 0.72, 0, Math.PI * 2);
    bumpCtx.fill();

    albedoCtx.strokeStyle = 'rgba(207, 216, 255, 0.28)';
    albedoCtx.lineWidth = 1.5;
    albedoCtx.beginPath();
    albedoCtx.arc(cx, cy, r, 0, Math.PI * 2);
    albedoCtx.stroke();

    // Select craters get crisp luminance rings that adopt active neon mood color
    if (i % 3 === 0) {
      emissiveCtx.strokeStyle = i % 6 === 0 ? 'rgba(255, 255, 255, 0.92)' : 'rgba(205, 220, 255, 0.78)';
      emissiveCtx.lineWidth = 2.2;
      emissiveCtx.beginPath();
      emissiveCtx.arc(cx, cy, r * 0.86, 0, Math.PI * 2);
      emissiveCtx.stroke();
    }
  }

  // Precision cybernetic latitude & meridian seams (scaled cleanly to 512x256)
  const latLines = [0.22, 0.38, 0.5, 0.62, 0.78];
  latLines.forEach((t, idx) => {
    const y = Math.round(height * t);
    const isEquator = idx === 2;

    albedoCtx.strokeStyle = isEquator ? 'rgba(207, 216, 255, 0.65)' : 'rgba(116, 130, 255, 0.28)';
    albedoCtx.lineWidth = isEquator ? 2.2 : 1.1;
    albedoCtx.beginPath();
    albedoCtx.moveTo(0, y);
    albedoCtx.lineTo(width, y);
    albedoCtx.stroke();

    bumpCtx.strokeStyle = '#2c2c2c';
    bumpCtx.lineWidth = isEquator ? 2.8 : 1.5;
    bumpCtx.beginPath();
    bumpCtx.moveTo(0, y);
    bumpCtx.lineTo(width, y);
    bumpCtx.stroke();

    roughCtx.strokeStyle = '#181818';
    roughCtx.lineWidth = 2;
    roughCtx.beginPath();
    roughCtx.moveTo(0, y);
    roughCtx.lineTo(width, y);
    roughCtx.stroke();

    emissiveCtx.strokeStyle = isEquator ? '#ffffff' : 'rgba(215, 225, 255, 0.78)';
    emissiveCtx.lineWidth = isEquator ? 2.5 : 1.2;
    emissiveCtx.beginPath();
    emissiveCtx.moveTo(0, y);
    emissiveCtx.lineTo(width, y);
    emissiveCtx.stroke();
  });

  // Segmented vertical meridian arcs + neon circuit nodes
  for (let m = 0; m < 12; m++) {
    const x = Math.round((m / 12) * width);
    albedoCtx.strokeStyle = 'rgba(146, 152, 176, 0.25)';
    albedoCtx.lineWidth = 1;
    albedoCtx.beginPath();
    albedoCtx.moveTo(x, 0);
    albedoCtx.lineTo(x, height);
    albedoCtx.stroke();

    bumpCtx.strokeStyle = '#383838';
    bumpCtx.lineWidth = 1.4;
    bumpCtx.beginPath();
    bumpCtx.moveTo(x, 0);
    bumpCtx.lineTo(x, height);
    bumpCtx.stroke();

    if (m % 2 === 0) {
      emissiveCtx.strokeStyle = 'rgba(225, 232, 255, 0.65)';
      emissiveCtx.lineWidth = 1.2;
      emissiveCtx.setLineDash([14, 9]);
      emissiveCtx.beginPath();
      emissiveCtx.moveTo(x, 22);
      emissiveCtx.lineTo(x, height - 22);
      emissiveCtx.stroke();
      emissiveCtx.setLineDash([]);

      // Luminous node pulse point at equator intersection
      emissiveCtx.fillStyle = '#ffffff';
      emissiveCtx.beginPath();
      emissiveCtx.arc(x, height * 0.5, 3, 0, Math.PI * 2);
      emissiveCtx.fill();
    }
  }

  const albedo = new THREE.CanvasTexture(albedoCanvas);
  albedo.colorSpace = THREE.SRGBColorSpace;
  albedo.wrapS = THREE.RepeatWrapping;
  albedo.wrapT = THREE.ClampToEdgeWrapping;
  albedo.anisotropy = maxAnisotropy;

  const bump = new THREE.CanvasTexture(bumpCanvas);
  bump.colorSpace = THREE.NoColorSpace;
  bump.wrapS = THREE.RepeatWrapping;
  bump.wrapT = THREE.ClampToEdgeWrapping;
  bump.anisotropy = maxAnisotropy;

  const roughness = new THREE.CanvasTexture(roughCanvas);
  roughness.colorSpace = THREE.NoColorSpace;
  roughness.wrapS = THREE.RepeatWrapping;
  roughness.wrapT = THREE.ClampToEdgeWrapping;
  roughness.anisotropy = maxAnisotropy;

  const emissive = new THREE.CanvasTexture(emissiveCanvas);
  emissive.colorSpace = THREE.SRGBColorSpace;
  emissive.wrapS = THREE.RepeatWrapping;
  emissive.wrapT = THREE.ClampToEdgeWrapping;
  emissive.anisotropy = maxAnisotropy;

  // Soft radial contact shadow disc texture
  const shadowCanvas = document.createElement('canvas');
  shadowCanvas.width = 128;
  shadowCanvas.height = 128;
  const sCtx = shadowCanvas.getContext('2d')!;
  const sGrad = sCtx.createRadialGradient(64, 64, 4, 64, 64, 62);
  sGrad.addColorStop(0, 'rgba(3, 4, 10, 0.92)');
  sGrad.addColorStop(0.55, 'rgba(6, 10, 24, 0.45)');
  sGrad.addColorStop(1, 'rgba(4, 6, 12, 0)');
  sCtx.fillStyle = sGrad;
  sCtx.fillRect(0, 0, 128, 128);
  const shadowDisc = new THREE.CanvasTexture(shadowCanvas);
  shadowDisc.colorSpace = THREE.SRGBColorSpace;

  return {
    albedo,
    bump,
    roughness,
    emissive,
    shadowDisc,
    dispose: () => {
      albedo.dispose();
      bump.dispose();
      roughness.dispose();
      emissive.dispose();
      shadowDisc.dispose();
    },
  };
}

export interface ObservatoryAssembly {
  root: THREE.Group;
  moonCore: THREE.Group;
  moonLattice: THREE.Mesh;
  outerRing: THREE.Mesh;
  innerRing: THREE.Mesh;
  satelliteRig: THREE.Group;
  tallyMaterial: THREE.MeshStandardMaterial;
  setMoodColors: (primaryHex: string, secondaryHex: string) => void;
  dispose: () => void;
}

const LANE_PYLON_COLORS = ['#b57bff', '#36d391', '#4fb0ff', '#ff6b8a'] as const;

export function buildObservatoryAssembly(
  textures: LunarTextures,
  isSoftwareGl: boolean
): ObservatoryAssembly {
  const disposables: Array<{ dispose: () => void }> = [];
  const root = new THREE.Group();

  // 1. Soft radial contact shadow plane at y = 0.015
  const shadowPlaneGeo = new THREE.CircleGeometry(3.0, 48);
  const shadowPlaneMat = new THREE.MeshBasicMaterial({
    map: textures.shadowDisc,
    transparent: true,
    opacity: 0.46,
    depthWrite: false,
  });
  const shadowPlane = new THREE.Mesh(shadowPlaneGeo, shadowPlaneMat);
  shadowPlane.rotation.x = -Math.PI / 2;
  shadowPlane.position.y = 0.015;
  root.add(shadowPlane);
  disposables.push(shadowPlaneGeo, shadowPlaneMat);

  // 2. Composite Plinth Group: dark obsidian octagon + neon base rim + brushed gunmetal collar + 4 multi-color neon pylons
  const plinthGroup = new THREE.Group();
  const octShape = new THREE.Shape();
  const sides = 8;
  const radius = 1.52;
  for (let i = 0; i < sides; i++) {
    const angle = (i / sides) * Math.PI * 2 + Math.PI / 8;
    const x = Math.cos(angle) * radius;
    const y = Math.sin(angle) * radius;
    if (i === 0) octShape.moveTo(x, y);
    else octShape.lineTo(x, y);
  }
  octShape.closePath();

  const plinthGeo = new THREE.ExtrudeGeometry(octShape, {
    depth: 0.24,
    bevelEnabled: true,
    bevelThickness: 0.05,
    bevelSize: 0.05,
    bevelSegments: 2,
  });
  plinthGeo.rotateX(-Math.PI / 2);
  const basaltMat = new THREE.MeshStandardMaterial({
    color: 0x101320,
    roughness: 0.78,
    metalness: 0.2,
  });
  const plinthMesh = new THREE.Mesh(plinthGeo, basaltMat);
  plinthMesh.position.y = 0.05; // flush bottom bevel at y = 0
  plinthMesh.castShadow = !isSoftwareGl;
  plinthMesh.receiveShadow = !isSoftwareGl;
  plinthGroup.add(plinthMesh);
  disposables.push(plinthGeo, basaltMat);

  // Neon base bezel collar circling the plinth
  const baseNeonGeo = new THREE.TorusGeometry(1.48, 0.02, 12, 64);
  baseNeonGeo.rotateX(Math.PI / 2);
  const primaryNeonMat = new THREE.MeshBasicMaterial({
    color: 0x7482ff,
    toneMapped: false,
  });
  const baseNeonRing = new THREE.Mesh(baseNeonGeo, primaryNeonMat);
  baseNeonRing.position.y = 0.31;
  plinthGroup.add(baseNeonRing);
  disposables.push(baseNeonGeo, primaryNeonMat);

  // Brushed dark-titanium pedestal collar (LatheGeometry)
  const collarPoints = [
    new THREE.Vector2(0.0, 0.0),
    new THREE.Vector2(1.08, 0.0),
    new THREE.Vector2(1.03, 0.16),
    new THREE.Vector2(0.78, 0.27),
    new THREE.Vector2(0.78, 0.35),
    new THREE.Vector2(0.0, 0.35),
  ];
  const collarGeo = new THREE.LatheGeometry(collarPoints, 32);
  const brushedDarkMetalMat = new THREE.MeshPhysicalMaterial({
    color: 0x20273f,
    metalness: 0.92,
    roughness: 0.22,
    anisotropy: 0.75,
    clearcoat: 0.35,
  });
  const collarMesh = new THREE.Mesh(collarGeo, brushedDarkMetalMat);
  collarMesh.position.y = 0.34;
  collarMesh.castShadow = !isSoftwareGl;
  collarMesh.receiveShadow = !isSoftwareGl;
  plinthGroup.add(collarMesh);
  disposables.push(collarGeo, brushedDarkMetalMat);

  // Secondary neon collar halo between pedestal and gimbal
  const collarNeonGeo = new THREE.TorusGeometry(0.84, 0.018, 12, 56);
  collarNeonGeo.rotateX(Math.PI / 2);
  const secondaryNeonMat = new THREE.MeshBasicMaterial({
    color: 0x4fb0ff,
    toneMapped: false,
  });
  const collarNeonMesh = new THREE.Mesh(collarNeonGeo, secondaryNeonMat);
  collarNeonMesh.position.y = 0.62;
  plinthGroup.add(collarNeonMesh);
  disposables.push(collarNeonGeo, secondaryNeonMat);

  // 4 Neon-Tipped Lane Pylons around plinth (Violet, Emerald, Cyber Blue, Neon Rose)
  const pylonBaseGeo = new THREE.CylinderGeometry(0.06, 0.08, 0.16, 8);
  const pylonTipGeo = new THREE.CylinderGeometry(0.048, 0.058, 0.05, 8);
  for (let i = 0; i < 4; i++) {
    const angle = (i / 4) * Math.PI * 2 + Math.PI / 4;
    const x = Math.cos(angle) * 1.22;
    const z = Math.sin(angle) * 1.22;

    const pylonBase = new THREE.Mesh(pylonBaseGeo, brushedDarkMetalMat);
    pylonBase.position.set(x, 0.38, z);
    pylonBase.castShadow = !isSoftwareGl;
    plinthGroup.add(pylonBase);

    const tipColor = new THREE.Color(LANE_PYLON_COLORS[i]);
    const tipMat = new THREE.MeshStandardMaterial({
      color: tipColor,
      emissive: tipColor,
      emissiveIntensity: 2.3,
      roughness: 0.2,
      metalness: 0.15,
    });
    const pylonTip = new THREE.Mesh(pylonTipGeo, tipMat);
    pylonTip.position.set(x, 0.485, z);
    plinthGroup.add(pylonTip);
    disposables.push(tipMat);
  }
  disposables.push(pylonBaseGeo, pylonTipGeo);
  root.add(plinthGroup);

  // 3. Dual-Axis Orbital Gimbal + Modern Cyber-Lunar Core centered at y = 1.78
  const gimbalGroup = new THREE.Group();
  gimbalGroup.position.y = 1.78;

  const outerRingMat = new THREE.MeshPhysicalMaterial({
    color: 0x283254,
    metalness: 0.9,
    roughness: 0.22,
    anisotropy: 0.7,
    clearcoat: 0.3,
  });
  const outerRingGeo = new THREE.TorusGeometry(1.5, 0.036, 18, 84);
  const outerRing = new THREE.Mesh(outerRingGeo, outerRingMat);
  outerRing.rotation.x = 0.35;
  outerRing.castShadow = !isSoftwareGl;

  // Neon edge-lit inner rail embedded inside outer gimbal ring
  const outerRailGeo = new THREE.TorusGeometry(1.455, 0.011, 10, 84);
  const outerRailMesh = new THREE.Mesh(outerRailGeo, primaryNeonMat);
  outerRing.add(outerRailMesh);
  gimbalGroup.add(outerRing);

  const innerRingMat = new THREE.MeshPhysicalMaterial({
    color: 0x7b8ec8,
    metalness: 0.94,
    roughness: 0.16,
    anisotropy: 0.8,
  });
  const innerRingGeo = new THREE.TorusGeometry(1.24, 0.028, 16, 72);
  const innerRing = new THREE.Mesh(innerRingGeo, innerRingMat);
  innerRing.rotation.y = 0.8;
  innerRing.castShadow = !isSoftwareGl;

  const innerRailGeo = new THREE.TorusGeometry(1.205, 0.009, 10, 72);
  const innerRailMesh = new THREE.Mesh(innerRailGeo, secondaryNeonMat);
  innerRing.add(innerRailMesh);
  gimbalGroup.add(innerRing);

  // 2 Trunnion pins with neon emitter caps
  const pinGeo = new THREE.CylinderGeometry(0.03, 0.03, 0.26, 12);
  const pinCapGeo = new THREE.SphereGeometry(0.038, 12, 12);
  for (let i = 0; i < 2; i++) {
    const sign = i === 0 ? 1 : -1;
    const pin = new THREE.Mesh(pinGeo, basaltMat);
    pin.position.set(sign * 1.37, 0, 0);
    pin.rotation.z = Math.PI / 2;
    gimbalGroup.add(pin);

    const cap = new THREE.Mesh(pinCapGeo, secondaryNeonMat);
    cap.position.set(sign * 1.51, 0, 0);
    gimbalGroup.add(cap);
  }
  disposables.push(
    outerRingMat,
    outerRingGeo,
    outerRailGeo,
    innerRingMat,
    innerRingGeo,
    innerRailGeo,
    pinGeo,
    pinCapGeo
  );

  // Modern Multi-Layer Cyber-Lunar Core (dark obsidian-circuit moon + glowing neon lattice + dual neon orbital rings)
  const moonCore = new THREE.Group();

  const moonShellGeo = new THREE.SphereGeometry(0.83, 48, 48);
  const moonShellMat = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    map: textures.albedo,
    bumpMap: textures.bump,
    bumpScale: 0.032,
    roughnessMap: textures.roughness,
    roughness: 0.45,
    metalness: 0.48,
    emissive: new THREE.Color(0x7482ff),
    emissiveMap: textures.emissive,
    emissiveIntensity: 2.4,
  });
  const moonShell = new THREE.Mesh(moonShellGeo, moonShellMat);
  moonShell.castShadow = !isSoftwareGl;
  moonShell.receiveShadow = !isSoftwareGl;
  moonCore.add(moonShell);

  // Floating geometric wireframe lattice around the modern moon
  const latticeGeo = new THREE.IcosahedronGeometry(0.95, 1);
  const latticeMat = new THREE.MeshBasicMaterial({
    color: 0x4fb0ff,
    wireframe: true,
    transparent: true,
    opacity: 0.62,
    toneMapped: false,
  });
  const moonLattice = new THREE.Mesh(latticeGeo, latticeMat);
  moonCore.add(moonLattice);

  // Dual intersecting glowing neon orbital belts hugging the modern moon
  const moonBeltGeo = new THREE.TorusGeometry(1.01, 0.016, 14, 96);
  moonBeltGeo.rotateX(Math.PI / 2 - 0.28);
  const moonBelt = new THREE.Mesh(moonBeltGeo, primaryNeonMat);
  moonCore.add(moonBelt);

  const moonBeltSecondaryGeo = new THREE.TorusGeometry(1.06, 0.012, 14, 96);
  moonBeltSecondaryGeo.rotateX(Math.PI / 2 + 0.42);
  moonBeltSecondaryGeo.rotateZ(0.35);
  const moonBeltSecondary = new THREE.Mesh(moonBeltSecondaryGeo, secondaryNeonMat);
  moonCore.add(moonBeltSecondary);

  // Polar neon beacon rings on top/bottom caps
  const poleRingGeo = new THREE.TorusGeometry(0.32, 0.013, 10, 48);
  poleRingGeo.rotateX(Math.PI / 2);
  const northPoleRing = new THREE.Mesh(poleRingGeo, secondaryNeonMat);
  northPoleRing.position.y = 0.78;
  const southPoleRing = new THREE.Mesh(poleRingGeo, secondaryNeonMat);
  southPoleRing.position.y = -0.78;
  moonCore.add(northPoleRing, southPoleRing);

  gimbalGroup.add(moonCore);
  disposables.push(
    moonShellGeo,
    moonShellMat,
    latticeGeo,
    latticeMat,
    moonBeltGeo,
    moonBeltSecondaryGeo,
    poleRingGeo
  );

  root.add(gimbalGroup);

  // 4. Composite 5-Part Cinema Camera Satellite orbiting the Lunar Core
  const satelliteRig = new THREE.Group();
  const satelliteGroup = new THREE.Group();
  satelliteGroup.position.set(2.08, 1.88, 0);
  satelliteGroup.lookAt(0, 1.78, 0);

  const camBodyShape = new THREE.Shape();
  camBodyShape.moveTo(-0.18, -0.13);
  camBodyShape.lineTo(0.18, -0.13);
  camBodyShape.lineTo(0.18, 0.13);
  camBodyShape.lineTo(-0.18, 0.13);
  camBodyShape.closePath();

  const camBodyGeo = new THREE.ExtrudeGeometry(camBodyShape, {
    depth: 0.34,
    bevelEnabled: true,
    bevelThickness: 0.025,
    bevelSize: 0.025,
    bevelSegments: 2,
  });
  camBodyGeo.center();
  const camBodyMesh = new THREE.Mesh(camBodyGeo, basaltMat);
  camBodyMesh.castShadow = !isSoftwareGl;
  satelliteGroup.add(camBodyMesh);

  // Lens barrel
  const barrelGeo = new THREE.CylinderGeometry(0.11, 0.125, 0.18, 24);
  barrelGeo.rotateX(Math.PI / 2);
  const barrelMesh = new THREE.Mesh(barrelGeo, innerRingMat);
  barrelMesh.position.z = 0.22;
  satelliteGroup.add(barrelMesh);

  // Beveled lens hood
  const hoodPoints = [
    new THREE.Vector2(0.11, 0),
    new THREE.Vector2(0.145, 0.09),
    new THREE.Vector2(0.135, 0.09),
    new THREE.Vector2(0.1, 0),
  ];
  const hoodGeo = new THREE.LatheGeometry(hoodPoints, 24);
  hoodGeo.rotateX(Math.PI / 2);
  const hoodMesh = new THREE.Mesh(hoodGeo, basaltMat);
  hoodMesh.position.z = 0.29;
  satelliteGroup.add(hoodMesh);

  // Optical glass objective lens (software-WebGL safe)
  const glassGeo = new THREE.CylinderGeometry(0.095, 0.095, 0.03, 24);
  glassGeo.rotateX(Math.PI / 2);
  const glassMat = new THREE.MeshPhysicalMaterial({
    color: 0xcfd8ff,
    roughness: 0.06,
    metalness: 0.05,
    ior: 1.54,
    clearcoat: 1.0,
    transparent: true,
    transmission: isSoftwareGl ? 0 : 0.9,
    opacity: isSoftwareGl ? 0.45 : 1,
    thickness: 0.35,
  });
  const glassMesh = new THREE.Mesh(glassGeo, glassMat);
  glassMesh.position.z = 0.31;
  satelliteGroup.add(glassMesh);

  // Emissive category tally ring on lens + rear camera accent stripe
  const tallyGeo = new THREE.TorusGeometry(0.118, 0.013, 12, 32);
  const tallyMaterial = new THREE.MeshStandardMaterial({
    color: 0x7482ff,
    emissive: 0x7482ff,
    emissiveIntensity: 2.4,
    roughness: 0.25,
    metalness: 0.2,
    toneMapped: false,
  });
  const tallyMesh = new THREE.Mesh(tallyGeo, tallyMaterial);
  tallyMesh.position.z = 0.26;
  satelliteGroup.add(tallyMesh);

  const rearBarGeo = new THREE.BoxGeometry(0.28, 0.025, 0.02);
  const rearBarMesh = new THREE.Mesh(rearBarGeo, secondaryNeonMat);
  rearBarMesh.position.set(0, 0.145, -0.05);
  satelliteGroup.add(rearBarMesh);

  disposables.push(
    camBodyGeo,
    barrelGeo,
    hoodGeo,
    glassGeo,
    glassMat,
    tallyGeo,
    tallyMaterial,
    rearBarGeo
  );
  satelliteRig.add(satelliteGroup);
  root.add(satelliteRig);

  const setMoodColors = (primaryHex: string, secondaryHex: string) => {
    primaryNeonMat.color.set(primaryHex);
    secondaryNeonMat.color.set(secondaryHex);

    tallyMaterial.color.set(primaryHex);
    tallyMaterial.emissive.set(primaryHex);

    moonShellMat.emissive.set(primaryHex);
    latticeMat.color.set(secondaryHex);
  };

  return {
    root,
    moonCore,
    moonLattice,
    outerRing,
    innerRing,
    satelliteRig,
    tallyMaterial,
    setMoodColors,
    dispose: () => {
      for (const item of disposables) {
        item.dispose();
      }
    },
  };
}

export function buildOrbitalStarfield(): {
  mesh: THREE.InstancedMesh;
  dispose: () => void;
} {
  const count = 120;
  const geo = new THREE.OctahedronGeometry(0.022, 0);
  const mat = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    emissive: 0xffffff,
    emissiveIntensity: 1.05,
    roughness: 0.3,
    metalness: 0.1,
  });
  const mesh = new THREE.InstancedMesh(geo, mat, count);
  const rand = seededNoise(918273);
  const dummy = new THREE.Object3D();
  const palette = [
    new THREE.Color('#cfd8ff'),
    new THREE.Color('#7482ff'),
    new THREE.Color('#b57bff'),
    new THREE.Color('#4fb0ff'),
    new THREE.Color('#36d391'),
    new THREE.Color('#ff6b8a'),
  ];

  for (let i = 0; i < count; i++) {
    const theta = rand() * Math.PI * 2;
    const phi = Math.acos(2 * rand() - 1);
    const radius = 3.5 + rand() * 5.2;

    dummy.position.set(
      Math.sin(phi) * Math.cos(theta) * radius,
      0.7 + Math.abs(Math.cos(phi)) * radius * 0.72,
      Math.sin(phi) * Math.sin(theta) * radius
    );
    const scale = 0.72 + rand() * 0.68;
    dummy.scale.setScalar(scale);
    dummy.rotation.set(rand() * Math.PI, rand() * Math.PI, 0);
    dummy.updateMatrix();
    mesh.setMatrixAt(i, dummy.matrix);
    mesh.setColorAt(i, palette[i % palette.length]);
  }

  mesh.instanceMatrix.needsUpdate = true;
  if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
  mesh.computeBoundingSphere();

  return {
    mesh,
    dispose: () => {
      geo.dispose();
      mat.dispose();
    },
  };
}
