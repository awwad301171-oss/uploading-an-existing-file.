export interface GroundingSource {
  title: string;
  url: string;
  domain: string;
}

export interface ChatMessageInput {
  role: 'user' | 'model';
  text: string;
}

export type NagiExpression = 'calm' | 'focused' | 'searching' | 'speaking';

export interface NagiExpressionMeta {
  label: string;
  accent: string;
}

const EXPRESSION_META: Record<NagiExpression, NagiExpressionMeta> = {
  calm: { label: 'Calm', accent: '#7482ff' },
  focused: { label: 'Focused', accent: '#b57bff' },
  searching: { label: 'Searching Web', accent: '#4fb0ff' },
  speaking: { label: 'Replying', accent: '#cfd8ff' },
};

export function getNagiExpressionMeta(expression: NagiExpression): NagiExpressionMeta {
  return EXPRESSION_META[expression] ?? EXPRESSION_META.calm;
}

export function extractGroundingSources(groundingMetadata: unknown): {
  sources: GroundingSource[];
  searchQueries: string[];
} {
  if (!groundingMetadata || typeof groundingMetadata !== 'object') {
    return { sources: [], searchQueries: [] };
  }

  const meta = groundingMetadata as {
    groundingChunks?: Array<{ web?: { uri?: unknown; title?: unknown } }>;
    webSearchQueries?: unknown[];
  };

  const sources: GroundingSource[] = [];
  const seenUrls = new Set<string>();

  if (Array.isArray(meta.groundingChunks)) {
    for (const chunk of meta.groundingChunks) {
      const rawUri = typeof chunk?.web?.uri === 'string' ? chunk.web.uri.trim() : '';
      if (!rawUri) continue;

      let parsed: URL;
      try {
        parsed = new URL(rawUri);
      } catch {
        continue;
      }

      if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
        continue;
      }

      const normalizedUrl = parsed.toString();
      if (seenUrls.has(normalizedUrl)) continue;
      seenUrls.add(normalizedUrl);

      const domain = parsed.hostname.replace(/^www\./i, '');
      const rawTitle = typeof chunk?.web?.title === 'string' ? chunk.web.title.trim() : '';
      const title = rawTitle.length > 0 ? rawTitle : domain;

      sources.push({
        title,
        url: normalizedUrl,
        domain,
      });

      if (sources.length >= 6) break;
    }
  }

  const searchQueries: string[] = [];
  const seenQueries = new Set<string>();

  if (Array.isArray(meta.webSearchQueries)) {
    for (const q of meta.webSearchQueries) {
      if (typeof q !== 'string') continue;
      const cleaned = q.trim();
      if (!cleaned) continue;
      const lower = cleaned.toLowerCase();
      if (seenQueries.has(lower)) continue;
      seenQueries.add(lower);
      searchQueries.push(cleaned);
      if (searchQueries.length >= 4) break;
    }
  }

  return { sources, searchQueries };
}

export function sanitizeChatHistory(rawMessages: unknown): ChatMessageInput[] {
  if (!Array.isArray(rawMessages)) return [];

  const valid: ChatMessageInput[] = [];
  for (const item of rawMessages) {
    if (!item || typeof item !== 'object') continue;
    const candidate = item as { role?: unknown; text?: unknown };
    if (candidate.role !== 'user' && candidate.role !== 'model') continue;
    if (typeof candidate.text !== 'string') continue;
    const trimmed = candidate.text.trim().slice(0, 4000);
    if (!trimmed) continue;
    valid.push({ role: candidate.role, text: trimmed });
  }

  // Ensure Gemini conversation history begins with a user turn
  while (valid.length > 0 && valid[0].role !== 'user') {
    valid.shift();
  }

  if (valid.length === 0) return [];

  // Normalize consecutive same-role turns so prior history strictly alternates user -> model
  const normalized: ChatMessageInput[] = [];
  for (const turn of valid) {
    const prev = normalized[normalized.length - 1];
    if (prev && prev.role === turn.role) {
      // Replace unanswered failed user turn with newer user turn (or combine cleanly)
      if (turn.role === 'user') {
        normalized[normalized.length - 1] = turn;
      } else {
        prev.text = `${prev.text}\n\n${turn.text}`.slice(0, 4000);
      }
    } else {
      normalized.push({ ...turn });
    }
  }

  return normalized;
}

export function formatGeminiApiError(rawMessage: string): {
  status: number;
  message: string;
} {
  let extracted = rawMessage.trim() || 'Unexpected server error.';
  const jsonStart = extracted.indexOf('{');
  if (jsonStart !== -1) {
    try {
      const parsed = JSON.parse(extracted.slice(jsonStart)) as {
        error?: { message?: string; status?: string };
      };
      if (parsed?.error?.message) {
        extracted = parsed.error.message;
      }
    } catch {
      // keep raw extracted text
    }
  }

  const lower = rawMessage.toLowerCase();
  if (
    lower.includes('api_key_invalid') ||
    lower.includes('permission_denied') ||
    lower.includes('reported as leaked') ||
    lower.includes('api key not valid')
  ) {
    return {
      status: 403,
      message: `${extracted} Check or select a valid GEMINI_API_KEY in the Settings > Secrets panel.`,
    };
  }

  if (lower.includes('resource_exhausted') || lower.includes('429')) {
    return {
      status: 429,
      message: `${extracted} Rate limit or quota exceeded—check your API key quota in Settings > Secrets.`,
    };
  }

  return { status: 500, message: extracted };
}
