import { motion } from 'motion/react';
import { PROCESS_STEPS } from '../data/portfolioData';

interface ProcessSectionProps {
  reducedMotion: boolean;
}

export function ProcessSection({ reducedMotion }: ProcessSectionProps) {
  return (
    <section
      id="process"
      aria-labelledby="process-heading"
      className="border-b border-[#20233a] bg-[#090a0f] py-20 sm:py-28"
    >
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="mb-14 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="font-mono-label text-xs uppercase tracking-[0.22em] text-[#9298b0]">
              How Each Edit Comes Together
            </p>
            <h2
              id="process-heading"
              className="mt-3 font-display text-3xl sm:text-5xl font-bold uppercase tracking-tight text-[#e9ecf8]"
            >
              Process
            </h2>
          </div>
          <p className="font-mono-label text-xs uppercase tracking-[0.18em] text-[#cfd8ff]">
            9:16 · 1080p Master
          </p>
        </div>

        {/* Sequential 4-step row with animated connecting line */}
        <div className="relative">
          {/* Desktop horizontal connecting track */}
          <div
            aria-hidden="true"
            className="hidden lg:block absolute left-0 right-0 top-6 h-px bg-[#20233a]"
          />
          {reducedMotion ? (
            <div
              aria-hidden="true"
              className="hidden lg:block absolute left-0 right-0 top-6 h-px bg-[#7482ff]"
            />
          ) : (
            <motion.div
              aria-hidden="true"
              initial={{ scaleX: 0 }}
              whileInView={{ scaleX: 1 }}
              viewport={{ once: true, amount: 0.4 }}
              transition={{ duration: 1.05, ease: [0.16, 1, 0.3, 1] }}
              style={{ transformOrigin: 'left center' }}
              className="hidden lg:block absolute left-0 right-0 top-6 h-px bg-gradient-to-r from-[#7482ff] via-[#cfd8ff] to-[#7482ff]"
            />
          )}

          <ol className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-4 lg:gap-6">
            {PROCESS_STEPS.map((step, index) => (
              <motion.li
                key={step.number}
                initial={reducedMotion ? false : { opacity: 0, y: 16 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.35 }}
                transition={{
                  duration: reducedMotion ? 0 : 0.45,
                  delay: reducedMotion ? 0 : index * 0.1,
                  ease: [0.16, 1, 0.3, 1],
                }}
                className="relative flex flex-col border border-[#20233a] bg-[#10121a] p-6 pt-10"
              >
                {/* Step index node */}
                <div className="mb-5 flex items-center justify-between border-b border-[#20233a] pb-4">
                  <span className="font-mono-label text-xs font-medium uppercase tracking-[0.2em] text-[#7482ff] tabular-nums">
                    Step {step.number}
                  </span>
                  <span className="font-mono-label text-[11px] uppercase tracking-[0.14em] text-[#9298b0]">
                    0{index + 1}/04
                  </span>
                </div>

                <h3 className="font-display text-lg sm:text-xl font-bold uppercase tracking-tight text-[#e9ecf8]">
                  {step.title}
                </h3>

                <p className="mt-3 text-sm text-[#9298b0] leading-relaxed">
                  {step.detail}
                </p>
              </motion.li>
            ))}
          </ol>
        </div>
      </div>
    </section>
  );
}
