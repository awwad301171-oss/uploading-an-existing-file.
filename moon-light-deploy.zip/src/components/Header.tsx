import { useEffect, useState } from 'react';
import { Menu, X } from 'lucide-react';
import { SITE_IDENTITY } from '../data/portfolioData';

interface HeaderProps {
  onNavigateSection: (sectionId: string) => void;
  onNavigateHome: () => void;
}

export function Header({ onNavigateSection, onNavigateHome }: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    if (!mobileMenuOpen) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setMobileMenuOpen(false);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [mobileMenuOpen]);

  const handleLinkClick = (sectionId: string) => {
    setMobileMenuOpen(false);
    onNavigateSection(sectionId);
  };

  return (
    <>
      <header className="sticky top-0 z-50 border-b border-[#20233a] bg-[#090a0f]/85 backdrop-blur-md">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-8 px-4 sm:px-6 lg:px-8">
          {/* Zone 1: Wordmark */}
          <a
            href="#top"
            onClick={(e) => {
              e.preventDefault();
              setMobileMenuOpen(false);
              onNavigateHome();
            }}
            className="font-display text-sm sm:text-base font-bold uppercase tracking-[0.18em] text-[#e9ecf8] whitespace-nowrap shrink-0 transition-colors hover:text-[#cfd8ff]"
          >
            {SITE_IDENTITY.brandName}
          </a>

          {/* Zone 2: Desktop nav links */}
          <nav
            aria-label="Primary navigation"
            className="hidden md:flex items-center gap-8"
          >
            <a
              href="#work"
              onClick={(e) => {
                e.preventDefault();
                handleLinkClick('work');
              }}
              className="text-sm font-medium text-[#9298b0] transition-colors hover:text-[#e9ecf8] whitespace-nowrap shrink-0"
            >
              Work
            </a>
            <a
              href="#studio-3d"
              onClick={(e) => {
                e.preventDefault();
                handleLinkClick('studio-3d');
              }}
              className="text-sm font-medium text-[#9298b0] transition-colors hover:text-[#e9ecf8] whitespace-nowrap shrink-0"
            >
              Studio
            </a>
            <a
              href="#about"
              onClick={(e) => {
                e.preventDefault();
                handleLinkClick('about');
              }}
              className="text-sm font-medium text-[#9298b0] transition-colors hover:text-[#e9ecf8] whitespace-nowrap shrink-0"
            >
              About
            </a>
            <a
              href="#contact"
              onClick={(e) => {
                e.preventDefault();
                handleLinkClick('contact');
              }}
              className="text-sm font-medium text-[#9298b0] transition-colors hover:text-[#e9ecf8] whitespace-nowrap shrink-0"
            >
              Contact
            </a>
          </nav>

          {/* Zone 3: Single action on desktop / Menu button on mobile */}
          <div className="flex items-center gap-3 shrink-0">
            <a
              href={SITE_IDENTITY.tiktokProfileUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="hidden md:inline-flex min-h-[40px] items-center border border-[#20233a] bg-[#10121a] px-4 py-2 font-mono-label text-xs uppercase tracking-[0.14em] text-[#cfd8ff] whitespace-nowrap shrink-0 transition-colors hover:border-[#7482ff] hover:text-[#e9ecf8]"
            >
              @lunex_xone
            </a>

            <button
              type="button"
              onClick={() => setMobileMenuOpen((prev) => !prev)}
              aria-expanded={mobileMenuOpen}
              aria-controls="mobile-nav-overlay"
              aria-label={mobileMenuOpen ? 'Close navigation menu' : 'Open navigation menu'}
              className="inline-flex md:hidden min-h-[44px] min-w-[44px] items-center justify-center border border-[#20233a] bg-[#10121a] text-[#e9ecf8] transition-colors hover:border-[#7482ff]"
            >
              {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile full-screen overlay menu */}
      {mobileMenuOpen && (
        <div
          id="mobile-nav-overlay"
          role="dialog"
          aria-modal="true"
          aria-label="Mobile navigation"
          className="fixed inset-0 z-40 flex flex-col justify-between bg-[#090a0f] px-6 pb-10 pt-24 md:hidden"
        >
          <nav aria-label="Mobile navigation links" className="flex flex-col border-t border-[#20233a]">
            {[
              { id: 'work', label: 'Work' },
              { id: 'studio-3d', label: 'Studio' },
              { id: 'about', label: 'About' },
              { id: 'contact', label: 'Contact' },
            ].map((item, idx) => (
              <a
                key={item.id}
                href={`#${item.id}`}
                onClick={(e) => {
                  e.preventDefault();
                  handleLinkClick(item.id);
                }}
                className="flex min-h-[64px] items-center justify-between border-b border-[#20233a] font-display text-2xl font-bold uppercase tracking-tight text-[#e9ecf8] transition-colors hover:text-[#7482ff]"
              >
                <span>{item.label}</span>
                <span className="font-mono-label text-xs text-[#9298b0]">0{idx + 1}</span>
              </a>
            ))}
          </nav>

          <div className="flex flex-col gap-4 border-t border-[#20233a] pt-6">
            <p className="font-mono-label text-xs uppercase tracking-[0.18em] text-[#9298b0]">
              Watch &amp; Follow
            </p>
            <a
              href={SITE_IDENTITY.tiktokProfileUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex min-h-[48px] items-center justify-center border border-[#7482ff] bg-[#10121a] px-6 py-3 font-mono-label text-xs uppercase tracking-[0.18em] text-[#e9ecf8]"
            >
              Follow on TikTok (@lunex_xone)
            </a>
          </div>
        </div>
      )}
    </>
  );
}
