import { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { RectAreaLightUniformsLib } from 'three/addons/lights/RectAreaLightUniformsLib.js';
import { ChevronDown, ChevronUp, RotateCcw } from 'lucide-react';
import {
  buildObservatoryAssembly,
  buildOrbitalStarfield,
  createLunarProceduralTextures,
  STUDIO_CAMERA_PRESETS,
  STUDIO_MOODS,
  type StudioCameraPresetId,
  type StudioMoodId,
} from '../utils/lunarScene3D';

interface LunarStudio3DProps {
  reducedMotion: boolean;
  tabVisible: boolean;
}

// Pre-allocated scratch vectors at module scope (zero GC inside animation loop)
const _targetCamPos = new THREE.Vector3();
const _targetOrbit = new THREE.Vector3();

export function LunarStudio3D({ reducedMotion, tabVisible }: LunarStudio3DProps) {
  const sectionRef = useRef<HTMLElement | null>(null);
  const canvasMountRef = useRef<HTMLDivElement | null>(null);

  const [activePreset, setActivePreset] = useState<StudioCameraPresetId>('overview');
  const [activeMood, setActiveMood] = useState<StudioMoodId>('indigo');
  const [controlsOpen, setControlsOpen] = useState(() =>
    typeof window !== 'undefined' ? window.innerWidth >= 640 : true
  );
  const [webglError, setWebglError] = useState<string | null>(null);

  const reducedMotionRef = useRef(reducedMotion);
  const tabVisibleRef = useRef(tabVisible);
  const inViewportRef = useRef(true);

  const sceneControllerRef = useRef<{
    applyPreset: (presetId: StudioCameraPresetId) => void;
    applyMood: (moodId: StudioMoodId) => void;
  } | null>(null);

  useEffect(() => {
    reducedMotionRef.current = reducedMotion;
  }, [reducedMotion]);

  useEffect(() => {
    tabVisibleRef.current = tabVisible;
  }, [tabVisible]);

  useEffect(() => {
    const mountEl = canvasMountRef.current;
    const sectionEl = sectionRef.current;
    if (!mountEl || !sectionEl) return;

    // Software WebGL probe via GPU renderer string (frees probe context immediately)
    const isSoftwareGl = (() => {
      try {
        const probeCanvas = document.createElement('canvas');
        const gl = probeCanvas.getContext('webgl2');
        if (!gl) return true;
        const ext = gl.getExtension('WEBGL_debug_renderer_info');
        const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
        const gpu = String(gl.getParameter(param) ?? '');
        gl.getExtension('WEBGL_lose_context')?.loseContext();
        return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
      } catch {
        return true;
      }
    })();

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({
        antialias: !isSoftwareGl,
        powerPreference: 'high-performance',
      });
    } catch {
      setWebglError('Interactive 3D viewport unavailable in this browser context.');
      return;
    }

    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.1;
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    const initialWidth = mountEl.clientWidth || 960;
    const initialHeight = mountEl.clientHeight || 560;
    renderer.setSize(initialWidth, initialHeight);
    renderer.domElement.style.display = 'block';
    renderer.domElement.style.width = '100%';
    renderer.domElement.style.height = '100%';
    renderer.domElement.setAttribute('aria-label', 'Interactive 3D Moon Light Orbital Studio');
    mountEl.innerHTML = '';
    mountEl.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    scene.background = new THREE.Color('#090a0f');
    scene.fog = new THREE.FogExp2('#090a0f', 0.052);

    const camera = new THREE.PerspectiveCamera(42, initialWidth / initialHeight, 0.1, 80);
    camera.position.set(4.2, 2.75, 5.4);

    // Mandatory Studio PBR Environment Map (balanced intensity so obsidian & neon colors stay vivid)
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    const roomEnv = new RoomEnvironment();
    const envTarget = pmremGenerator.fromScene(roomEnv, 0.04);
    scene.environment = envTarget.texture;
    scene.environmentIntensity = 0.55;
    roomEnv.dispose();
    pmremGenerator.dispose();

    // Horizon Studio Ground Stage (dark obsidian floor seamlessly fogged into night sky)
    const floorGeo = new THREE.CircleGeometry(28, 48);
    const floorMat = new THREE.MeshStandardMaterial({
      color: 0x06070b,
      roughness: 0.9,
      metalness: 0.08,
    });
    const floorMesh = new THREE.Mesh(floorGeo, floorMat);
    floorMesh.rotation.x = -Math.PI / 2;
    floorMesh.position.y = 0;
    floorMesh.receiveShadow = !isSoftwareGl;
    scene.add(floorMesh);

    // Concentric neon-accented orbital stage rings slightly raised (+0.02 Y offset avoids Z-fighting)
    const stageRingGeo = new THREE.RingGeometry(2.6, 2.645, 96);
    const stageRingMat = new THREE.MeshBasicMaterial({
      color: 0x7482ff,
      transparent: true,
      opacity: 0.85,
      toneMapped: false,
      side: THREE.DoubleSide,
    });
    const stageRing = new THREE.Mesh(stageRingGeo, stageRingMat);
    stageRing.rotation.x = -Math.PI / 2;
    stageRing.position.y = 0.022;
    scene.add(stageRing);

    const outerFloorRingGeo = new THREE.RingGeometry(3.45, 3.485, 96);
    const outerFloorRingMat = new THREE.MeshBasicMaterial({
      color: 0x4fb0ff,
      transparent: true,
      opacity: 0.55,
      toneMapped: false,
      side: THREE.DoubleSide,
    });
    const outerFloorRing = new THREE.Mesh(outerFloorRingGeo, outerFloorRingMat);
    outerFloorRing.rotation.x = -Math.PI / 2;
    outerFloorRing.position.y = 0.024;
    scene.add(outerFloorRing);

    // 3-Point Studio Rig + Dual-Tone Neon Rim Contrast
    const hemiLight = new THREE.HemisphereLight(0xa3b6ff, 0x0b0d16, 0.9);
    scene.add(hemiLight);

    const keyLight = new THREE.DirectionalLight(0xffe7cb, 2.5);
    keyLight.position.set(4.5, 6.8, 3.8);
    keyLight.castShadow = !isSoftwareGl;
    keyLight.shadow.mapSize.set(1024, 1024);
    keyLight.shadow.camera.near = 1;
    keyLight.shadow.camera.far = 18;
    keyLight.shadow.camera.left = -4.5;
    keyLight.shadow.camera.right = 4.5;
    keyLight.shadow.camera.top = 4.5;
    keyLight.shadow.camera.bottom = -4.5;
    keyLight.shadow.bias = -0.0005;
    keyLight.shadow.normalBias = 0.02;
    scene.add(keyLight);

    const rimLight = new THREE.PointLight(0x7482ff, 7.0, 18, 1.4);
    rimLight.position.set(-3.4, 2.9, -3.2);
    scene.add(rimLight);

    const secondaryRimLight = new THREE.PointLight(0x4fb0ff, 5.8, 18, 1.4);
    secondaryRimLight.position.set(3.4, 2.4, 2.8);
    scene.add(secondaryRimLight);

    let rectLight: THREE.RectAreaLight | null = null;
    if (!isSoftwareGl) {
      RectAreaLightUniformsLib.init();
      rectLight = new THREE.RectAreaLight(0xcfd8ff, 3.0, 4.5, 1.4);
      rectLight.position.set(0, 4.8, -3.2);
      rectLight.lookAt(0, 1.6, 0);
      scene.add(rectLight);
    }

    // Procedural Textures + Composite Observatory + Starfield
    const maxAnisotropy = renderer.capabilities.getMaxAnisotropy();
    const textures = createLunarProceduralTextures(maxAnisotropy);
    const observatory = buildObservatoryAssembly(textures, isSoftwareGl);
    scene.add(observatory.root);

    const stars = buildOrbitalStarfield();
    scene.add(stars.mesh);

    // OrbitControls
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.target.set(0, 1.55, 0);
    controls.enableDamping = !isSoftwareGl;
    controls.dampingFactor = 0.07;
    controls.enablePan = false;
    controls.minDistance = 3.2;
    controls.maxDistance = 11.5;
    controls.maxPolarAngle = Math.PI * 0.56;
    controls.update();

    // Camera transition state (damped smoothly, cleared on arrival or manual drag)
    let transitionActive = false;
    _targetCamPos.copy(camera.position);
    _targetOrbit.copy(controls.target);

    const onControlStart = () => {
      transitionActive = false;
    };
    controls.addEventListener('start', onControlStart);

    if (!isSoftwareGl) {
      renderer.compile(scene, camera);
    }

    let rafId = 0;
    let timerId = 0;
    let disposed = false;
    let contextLost = false;
    let renderBusy = false;
    let renderDirty = false;
    let loopRunning = false;
    let lastTime = performance.now();

    function afterDraw(cb: () => void) {
      if (disposed) return;
      const gl = renderer.getContext() as WebGL2RenderingContext;
      const sync = gl.fenceSync ? gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0) : null;
      if (!sync) {
        timerId = window.setTimeout(cb, 80);
        return;
      }
      gl.flush();
      const poll = () => {
        if (disposed) {
          gl.deleteSync(sync);
          return;
        }
        const state = gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (state === gl.UNSIGNALED) {
          timerId = window.setTimeout(poll, 5);
        } else {
          gl.deleteSync(sync);
          timerId = window.setTimeout(cb, 80);
        }
      };
      timerId = window.setTimeout(poll, 5);
    }

    function advanceScene(delta: number) {
      const animDt = Math.min(delta, 0.1);
      const camDt = Math.min(delta, 0.35);

      if (!reducedMotionRef.current) {
        observatory.moonCore.rotation.y += animDt * 0.18;
        observatory.moonLattice.rotation.y -= animDt * 0.28;
        observatory.moonLattice.rotation.x += animDt * 0.09;
        observatory.outerRing.rotation.y += animDt * 0.28;
        observatory.outerRing.rotation.z += animDt * 0.08;
        observatory.innerRing.rotation.x += animDt * 0.22;
        observatory.satelliteRig.rotation.y -= animDt * 0.34;
        stars.mesh.rotation.y += animDt * 0.025;
      }

      if (transitionActive) {
        if (reducedMotionRef.current) {
          camera.position.copy(_targetCamPos);
          controls.target.copy(_targetOrbit);
          transitionActive = false;
        } else {
          const lambda = 7.5;
          camera.position.x = THREE.MathUtils.damp(camera.position.x, _targetCamPos.x, lambda, camDt);
          camera.position.y = THREE.MathUtils.damp(camera.position.y, _targetCamPos.y, lambda, camDt);
          camera.position.z = THREE.MathUtils.damp(camera.position.z, _targetCamPos.z, lambda, camDt);
          controls.target.x = THREE.MathUtils.damp(controls.target.x, _targetOrbit.x, lambda, camDt);
          controls.target.y = THREE.MathUtils.damp(controls.target.y, _targetOrbit.y, lambda, camDt);
          controls.target.z = THREE.MathUtils.damp(controls.target.z, _targetOrbit.z, lambda, camDt);

          if (
            camera.position.distanceToSquared(_targetCamPos) < 0.0005 &&
            controls.target.distanceToSquared(_targetOrbit) < 0.0005
          ) {
            camera.position.copy(_targetCamPos);
            controls.target.copy(_targetOrbit);
            transitionActive = false;
          }
        }
      }

      controls.update();
    }

    function requestRender() {
      if (disposed || contextLost) return;
      // When the continuous loop is active, avoid double-scheduling overlapping CPU renders
      if (loopRunning && !reducedMotionRef.current) return;
      if (renderBusy) {
        renderDirty = true;
        return;
      }
      renderBusy = true;
      rafId = window.requestAnimationFrame((now) => {
        if (disposed || contextLost) {
          renderBusy = false;
          return;
        }
        renderDirty = false;
        const dt = (now - lastTime) / 1000;
        lastTime = now;
        advanceScene(dt);
        renderer.render(scene, camera);

        const done = () => {
          renderBusy = false;
          if (transitionActive || renderDirty) {
            requestRender();
          }
        };

        if (isSoftwareGl) {
          afterDraw(done);
        } else {
          done();
        }
      });
    }

    function tick(now: number) {
      if (disposed || contextLost) {
        loopRunning = false;
        return;
      }
      if (reducedMotionRef.current) {
        loopRunning = false;
        requestRender();
        return;
      }
      if (!tabVisibleRef.current || !inViewportRef.current) {
        loopRunning = false;
        timerId = window.setTimeout(() => {
          if (!disposed) {
            lastTime = performance.now();
            loopRunning = true;
            rafId = window.requestAnimationFrame(tick);
          }
        }, 250);
        return;
      }

      loopRunning = true;
      const dt = (now - lastTime) / 1000;
      lastTime = now;
      advanceScene(dt);
      renderer.render(scene, camera);

      if (isSoftwareGl) {
        afterDraw(() => {
          if (!disposed) {
            rafId = window.requestAnimationFrame(tick);
          }
        });
      } else {
        rafId = window.requestAnimationFrame(tick);
      }
    }

    const onControlsChange = () => {
      if (reducedMotionRef.current) {
        requestRender();
      }
    };
    controls.addEventListener('change', onControlsChange);

    // Imperative controller hooks for bottom dock UI
    sceneControllerRef.current = {
      applyPreset: (presetId: StudioCameraPresetId) => {
        const preset = STUDIO_CAMERA_PRESETS.find((p) => p.id === presetId);
        if (!preset) return;
        _targetCamPos.set(...preset.position);
        _targetOrbit.set(...preset.target);
        transitionActive = true;
        requestRender();
      },
      applyMood: (moodId: StudioMoodId) => {
        const mood = STUDIO_MOODS.find((m) => m.id === moodId);
        if (!mood) return;
        rimLight.color.set(mood.accentHex);
        rimLight.intensity = mood.rimIntensity;
        secondaryRimLight.color.set(mood.secondaryHex);
        stageRingMat.color.set(mood.accentHex);
        outerFloorRingMat.color.set(mood.secondaryHex);
        observatory.setMoodColors(mood.accentHex, mood.secondaryHex);
        requestRender();
      },
    };

    // ResizeObserver for crisp responsive scaling (preserve frame when backing store resizes)
    let prevWidth = initialWidth;
    let prevHeight = initialHeight;
    const resizeObserver = new ResizeObserver((entries) => {
      const entry = entries[0];
      if (!entry || disposed) return;
      const width = Math.max(200, Math.floor(entry.contentRect.width));
      const height = Math.max(240, Math.floor(entry.contentRect.height));
      if (width === prevWidth && height === prevHeight) return;
      prevWidth = width;
      prevHeight = height;
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      renderer.setSize(width, height, false);
      if (!contextLost) {
        renderer.render(scene, camera);
      }
      requestRender();
    });
    resizeObserver.observe(mountEl);

    // Viewport pause observer
    const io = new IntersectionObserver(
      (entries) => {
        const visible = entries[0]?.isIntersecting ?? true;
        inViewportRef.current = visible;
        if (visible && !reducedMotionRef.current && !loopRunning && !disposed && !contextLost) {
          window.clearTimeout(timerId);
          loopRunning = true;
          lastTime = performance.now();
          rafId = window.requestAnimationFrame(tick);
        }
      },
      { threshold: 0.05 }
    );
    io.observe(sectionEl);

    // Context loss resilience
    const handleContextLost = (e: Event) => {
      e.preventDefault();
      contextLost = true;
      loopRunning = false;
    };
    const handleContextRestored = () => {
      contextLost = false;
      requestRender();
    };
    renderer.domElement.addEventListener('webglcontextlost', handleContextLost);
    renderer.domElement.addEventListener('webglcontextrestored', handleContextRestored);

    // Initial render + start loop
    renderer.render(scene, camera);
    if (!reducedMotionRef.current) {
      loopRunning = true;
      lastTime = performance.now();
      rafId = window.requestAnimationFrame(tick);
    }

    return () => {
      disposed = true;
      window.cancelAnimationFrame(rafId);
      window.clearTimeout(timerId);
      resizeObserver.disconnect();
      io.disconnect();
      controls.removeEventListener('start', onControlStart);
      controls.removeEventListener('change', onControlsChange);
      controls.dispose();
      renderer.domElement.removeEventListener('webglcontextlost', handleContextLost);
      renderer.domElement.removeEventListener('webglcontextrestored', handleContextRestored);
      observatory.dispose();
      stars.dispose();
      textures.dispose();
      floorGeo.dispose();
      floorMat.dispose();
      stageRingGeo.dispose();
      stageRingMat.dispose();
      outerFloorRingGeo.dispose();
      outerFloorRingMat.dispose();
      envTarget.dispose();
      renderer.dispose();
      sceneControllerRef.current = null;
    };
  }, []);

  const handlePresetClick = (presetId: StudioCameraPresetId) => {
    setActivePreset(presetId);
    sceneControllerRef.current?.applyPreset(presetId);
  };

  const handleMoodClick = (moodId: StudioMoodId) => {
    setActiveMood(moodId);
    sceneControllerRef.current?.applyMood(moodId);
  };

  const activeMoodObj = STUDIO_MOODS.find((m) => m.id === activeMood) ?? STUDIO_MOODS[0];

  return (
    <section
      ref={sectionRef}
      id="studio-3d"
      data-testid="lunar-studio-3d"
      aria-labelledby="studio-3d-heading"
      className="border-b border-[#20233a] bg-[#090a0f] py-20 sm:py-28"
    >
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="mb-10 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="font-mono-label text-xs uppercase tracking-[0.22em] text-[#9298b0]">
              Interactive 3D Stage
            </p>
            <h2
              id="studio-3d-heading"
              className="mt-3 font-display text-3xl sm:text-5xl font-bold uppercase tracking-tight text-[#e9ecf8]"
            >
              Orbital Rig
            </h2>
          </div>
          <p className="max-w-md text-sm sm:text-base text-[#9298b0]">
            Drag to orbit the lunar observatory, switch camera angles, and test each category&apos;s lighting mood.
          </p>
        </div>

        {/* Dedicated 3D Stage Container — isolated mount ref, no backdrop-filter over WebGL */}
        <div className="relative h-[460px] sm:h-[560px] w-full overflow-hidden border border-[#20233a] bg-[#090a0f]">
          {/* Isolated WebGL canvas mount */}
          <div ref={canvasMountRef} className="h-full w-full" />

          {webglError && (
            <div className="absolute inset-0 flex items-center justify-center bg-[#090a0f] p-6 text-center">
              <p className="font-mono-label text-xs uppercase tracking-[0.18em] text-[#9298b0]">
                {webglError}
              </p>
            </div>
          )}

          {/* Minimal top-left static spec badge (no backdrop-filter, no pulsing dot) */}
          <div className="pointer-events-none absolute left-4 top-4 z-10 border border-[#20233a] bg-[#10121a]/92 px-3 py-2">
            <p className="font-mono-label text-[11px] uppercase tracking-[0.18em] text-[#cfd8ff]">
              Lunar Camera Rig ·{' '}
              <span style={{ color: activeMoodObj.accentHex }}>{activeMoodObj.label}</span>
            </p>
          </div>

          {/* Collapsible Bottom Control Dock (center remains 100% unobstructed) */}
          <div className="pointer-events-none absolute inset-x-0 bottom-4 z-10 flex flex-col items-center px-3">
            <button
              type="button"
              onClick={() => setControlsOpen((prev) => !prev)}
              data-testid="studio-3d-toggle-controls"
              aria-expanded={controlsOpen}
              className="pointer-events-auto mb-2 inline-flex min-h-[36px] items-center gap-2 border border-[#20233a] bg-[#10121a]/95 px-3 py-1.5 font-mono-label text-[11px] uppercase tracking-[0.16em] text-[#cfd8ff] transition-colors hover:border-[#7482ff] hover:text-[#e9ecf8]"
            >
              {controlsOpen ? (
                <>
                  <ChevronDown className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>Hide Controls</span>
                </>
              ) : (
                <>
                  <ChevronUp className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>Show Controls</span>
                </>
              )}
            </button>

            {controlsOpen && (
              <div
                data-testid="studio-3d-dock"
                className="pointer-events-auto flex max-w-[94vw] flex-wrap items-center justify-center gap-2 sm:gap-3 border border-[#20233a] bg-[#10121a]/95 px-3 py-2 sm:px-4 sm:py-3"
              >
                {/* Camera presets */}
                <div className="flex flex-wrap items-center justify-center gap-1 sm:gap-1.5">
                  <span className="mr-1 font-mono-label text-[10px] uppercase tracking-[0.16em] text-[#9298b0]">
                    View
                  </span>
                  {STUDIO_CAMERA_PRESETS.map((preset) => {
                    const selected = activePreset === preset.id;
                    return (
                      <button
                        key={preset.id}
                        type="button"
                        onClick={() => handlePresetClick(preset.id)}
                        data-testid={`studio-preset-${preset.id}`}
                        aria-pressed={selected}
                        className={`min-h-[30px] sm:min-h-[34px] border px-2 py-1 sm:px-2.5 font-mono-label text-[10px] sm:text-[11px] uppercase tracking-[0.12em] sm:tracking-[0.14em] transition-colors ${
                          selected
                            ? 'border-[#cfd8ff] bg-[#7482ff] text-[#090a0f]'
                            : 'border-[#20233a] bg-[#090a0f] text-[#cfd8ff] hover:border-[#7482ff]'
                        }`}
                      >
                        {preset.label}
                      </button>
                    );
                  })}
                </div>

                <div className="hidden h-5 w-px bg-[#20233a] sm:block" aria-hidden="true" />

                {/* Category lighting mood swatches */}
                <div className="flex flex-wrap items-center justify-center gap-1 sm:gap-1.5">
                  <span className="mr-1 font-mono-label text-[10px] uppercase tracking-[0.16em] text-[#9298b0]">
                    Mood
                  </span>
                  {STUDIO_MOODS.map((mood) => {
                    const selected = activeMood === mood.id;
                    return (
                      <button
                        key={mood.id}
                        type="button"
                        onClick={() => handleMoodClick(mood.id)}
                        data-testid={`studio-mood-${mood.id}`}
                        aria-pressed={selected}
                        className="inline-flex min-h-[30px] sm:min-h-[34px] items-center gap-1.5 border px-2 py-1 sm:px-2.5 font-mono-label text-[10px] sm:text-[11px] uppercase tracking-[0.12em] sm:tracking-[0.14em] transition-colors"
                        style={{
                          borderColor: selected ? mood.accentHex : '#20233a',
                          backgroundColor: selected ? '#171a26' : '#090a0f',
                          color: selected ? mood.accentHex : '#9298b0',
                        }}
                      >
                        <span
                          aria-hidden="true"
                          className="h-2 w-2 shrink-0"
                          style={{ backgroundColor: mood.accentHex }}
                        />
                        <span>{mood.label}</span>
                      </button>
                    );
                  })}
                </div>

                <button
                  type="button"
                  onClick={() => {
                    handlePresetClick('overview');
                    handleMoodClick('indigo');
                  }}
                  aria-label="Reset 3D camera and mood"
                  className="inline-flex min-h-[30px] sm:min-h-[34px] items-center gap-1 border border-[#20233a] bg-[#090a0f] px-2 py-1 sm:px-2.5 font-mono-label text-[10px] sm:text-[11px] uppercase tracking-[0.12em] sm:tracking-[0.14em] text-[#9298b0] transition-colors hover:border-[#7482ff] hover:text-[#e9ecf8]"
                >
                  <RotateCcw className="h-3 w-3" aria-hidden="true" />
                  <span>Reset</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
