import { ArrowLeft, ArrowRight, ArrowUpRight } from 'lucide-react';
import { PROJECTS, type CategorySlug, type ProjectItem } from '../data/portfolioData';
import { getNextProject } from '../utils/moonMath';
import { ProjectArtwork } from './ProjectArtwork';

interface ProjectPageProps {
  project: ProjectItem;
  onBack: () => void;
  onSelectProject: (slug: CategorySlug) => void;
}

export function ProjectPage({ project, onBack, onSelectProject }: ProjectPageProps) {
  const nextProject = getNextProject(project.slug, PROJECTS);

  return (
    <article
      data-testid={`project-page-${project.slug}`}
      className="min-h-[85vh] bg-[#090a0f] pb-24 pt-10 sm:pt-14"
    >
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        {/* Back link */}
        <button
          type="button"
          onClick={onBack}
          className="inline-flex min-h-[44px] items-center gap-2.5 border border-[#20233a] bg-[#10121a] px-4 py-2 font-mono-label text-xs uppercase tracking-[0.18em] text-[#cfd8ff] transition-colors hover:border-[#7482ff] hover:text-[#e9ecf8]"
        >
          <ArrowLeft className="h-4 w-4" aria-hidden="true" />
          <span>Back to work</span>
        </button>

        {/* Header block */}
        <header className="mt-10 border-b border-[#20233a] pb-10">
          <p
            className="font-mono-label text-xs uppercase tracking-[0.22em]"
            style={{ color: project.accentColor }}
          >
            {project.tag}
          </p>

          <h1 className="mt-4 font-display text-4xl sm:text-6xl lg:text-7xl font-extrabold uppercase tracking-[-0.03em] text-[#e9ecf8] text-balance">
            {project.title}
          </h1>

          <p className="mt-5 max-w-2xl text-lg sm:text-xl text-[#9298b0] leading-relaxed">
            {project.tagline}
          </p>
        </header>

        {/* Full-width topic cover */}
        <div className="mt-10 aspect-[16/7] w-full overflow-hidden border border-[#20233a] bg-[#10121a]">
          <ProjectArtwork slug={project.slug} variant="banner" alt={project.coverAlt} />
        </div>

        {/* Two columns: Description & Facts */}
        <div className="mt-14 grid grid-cols-1 gap-12 lg:grid-cols-12">
          <div className="lg:col-span-7 space-y-6">
            <h2 className="font-mono-label text-xs uppercase tracking-[0.22em] text-[#9298b0]">
              Creative Direction
            </h2>
            {project.description.map((paragraph, idx) => (
              <p key={idx} className="text-base sm:text-lg text-[#e9ecf8]/90 leading-relaxed">
                {paragraph}
              </p>
            ))}

            <div className="pt-4">
              <a
                href={project.tiktokUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex min-h-[48px] items-center gap-2.5 border px-6 py-3 font-mono-label text-xs uppercase tracking-[0.18em] text-[#090a0f] transition-opacity hover:opacity-90"
                style={{
                  backgroundColor: project.accentColor,
                  borderColor: project.accentColor,
                }}
              >
                <span>Watch on TikTok</span>
                <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
              </a>
            </div>
          </div>

          <aside className="lg:col-span-5">
            <div className="border border-[#20233a] bg-[#10121a] p-6 sm:p-8">
              <h2 className="font-mono-label text-xs uppercase tracking-[0.22em] text-[#9298b0]">
                Project Facts
              </h2>
              <dl className="mt-6 divide-y divide-[#20233a] border-t border-[#20233a]">
                <div className="py-4">
                  <dt className="font-mono-label text-[11px] uppercase tracking-[0.18em] text-[#9298b0]">
                    Format
                  </dt>
                  <dd className="mt-1.5 text-sm sm:text-base font-medium text-[#e9ecf8]">
                    {project.facts.format}
                  </dd>
                </div>
                <div className="py-4">
                  <dt className="font-mono-label text-[11px] uppercase tracking-[0.18em] text-[#9298b0]">
                    Focus
                  </dt>
                  <dd className="mt-1.5 text-sm sm:text-base font-medium text-[#e9ecf8]">
                    {project.facts.focus}
                  </dd>
                </div>
                <div className="py-4">
                  <dt className="font-mono-label text-[11px] uppercase tracking-[0.18em] text-[#9298b0]">
                    Published on
                  </dt>
                  <dd className="mt-1.5 text-sm sm:text-base font-medium text-[#e9ecf8]">
                    {project.facts.publishedOn}
                  </dd>
                </div>
              </dl>
            </div>
          </aside>
        </div>

        {/* Next project cyclic footer link */}
        <div className="mt-20 border-t border-[#20233a] pt-10">
          <button
            type="button"
            onClick={() => onSelectProject(nextProject.slug)}
            data-testid="next-project-button"
            className="group flex w-full items-center justify-between border border-[#20233a] bg-[#10121a] p-6 sm:p-8 text-left transition-colors hover:border-[#7482ff]"
          >
            <div>
              <p className="font-mono-label text-xs uppercase tracking-[0.2em] text-[#9298b0]">
                Next project
              </p>
              <p className="mt-2 font-display text-2xl sm:text-4xl font-bold uppercase tracking-tight text-[#e9ecf8] transition-colors group-hover:text-[#cfd8ff]">
                {nextProject.title}
              </p>
            </div>
            <ArrowRight
              className="h-6 w-6 shrink-0 text-[#cfd8ff] transition-transform duration-200 group-hover:translate-x-1.5"
              aria-hidden="true"
            />
          </button>
        </div>
      </div>
    </article>
  );
}
