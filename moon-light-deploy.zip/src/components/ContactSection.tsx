import { useState } from 'react';
import { ArrowUpRight, Check, Copy } from 'lucide-react';
import { SITE_IDENTITY, SOCIAL_LINKS } from '../data/portfolioData';

export function ContactSection() {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(SITE_IDENTITY.handle);
      setCopied(true);
    } catch {
      // Fallback copy for restricted browser contexts
      const textarea = document.createElement('textarea');
      textarea.value = SITE_IDENTITY.handle;
      textarea.style.position = 'fixed';
      textarea.style.opacity = '0';
      document.body.appendChild(textarea);
      textarea.select();
      try {
        document.execCommand('copy');
        setCopied(true);
      } finally {
        document.body.removeChild(textarea);
      }
    }

    window.setTimeout(() => setCopied(false), 2400);
  };

  return (
    <section
      id="contact"
      aria-labelledby="contact-heading"
      className="border-b border-[#20233a] bg-[#090a0f] py-20 sm:py-28"
    >
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="mb-12 flex flex-col gap-6 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="font-mono-label text-xs uppercase tracking-[0.22em] text-[#9298b0]">
              Elsewhere in the Night Sky
            </p>
            <h2
              id="contact-heading"
              className="mt-3 font-display text-3xl sm:text-5xl font-bold uppercase tracking-tight text-[#e9ecf8]"
            >
              Contact
            </h2>
          </div>

          <button
            type="button"
            onClick={handleCopy}
            data-testid="copy-handle-button"
            className="inline-flex min-h-[48px] items-center gap-3 self-start border border-[#20233a] bg-[#10121a] px-5 py-3 font-mono-label text-xs uppercase tracking-[0.16em] text-[#cfd8ff] transition-colors hover:border-[#7482ff] hover:text-[#e9ecf8]"
          >
            {copied ? (
              <>
                <Check className="h-4 w-4 text-[#36d391]" aria-hidden="true" />
                <span>Copied {SITE_IDENTITY.handle}</span>
              </>
            ) : (
              <>
                <Copy className="h-4 w-4" aria-hidden="true" />
                <span>Copy {SITE_IDENTITY.handle}</span>
              </>
            )}
          </button>
        </div>

        {/* Big social list */}
        <div className="border-t border-[#20233a]">
          {SOCIAL_LINKS.map((item) => {
            if (!item.url) {
              return (
                <div
                  key={item.id}
                  aria-disabled="true"
                  className="flex min-h-[88px] flex-col justify-center gap-2 border-b border-[#20233a] py-6 opacity-55 sm:flex-row sm:items-center sm:justify-between cursor-not-allowed"
                >
                  <span className="font-display text-2xl sm:text-4xl font-bold uppercase tracking-tight text-[#9298b0]">
                    {item.platform}
                  </span>
                  <div className="flex items-center gap-6">
                    <span className="font-mono-label text-xs uppercase tracking-[0.18em] text-[#9298b0]">
                      {item.handle}
                    </span>
                    <span
                      aria-hidden="true"
                      className="font-mono-label text-xs uppercase tracking-[0.16em] text-[#9298b0]"
                    >
                      —
                    </span>
                  </div>
                </div>
              );
            }

            return (
              <a
                key={item.id}
                href={item.url}
                target="_blank"
                rel="noopener noreferrer"
                className="group flex min-h-[88px] flex-col justify-center gap-2 border-b border-[#20233a] py-6 transition-all duration-200 hover:bg-[#10121a] hover:px-4 sm:flex-row sm:items-center sm:justify-between"
              >
                <span className="font-display text-2xl sm:text-4xl font-bold uppercase tracking-tight text-[#e9ecf8] transition-transform duration-200 group-hover:translate-x-2">
                  {item.platform}
                </span>

                <div className="flex items-center gap-6">
                  <span className="font-mono-label text-xs uppercase tracking-[0.18em] text-[#9298b0] transition-colors group-hover:text-[#cfd8ff]">
                    {item.handle}
                  </span>
                  <ArrowUpRight
                    className="h-5 w-5 text-[#9298b0] transition-all duration-200 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 group-hover:text-[#7482ff]"
                    aria-hidden="true"
                  />
                </div>
              </a>
            );
          })}
        </div>
      </div>
    </section>
  );
}
