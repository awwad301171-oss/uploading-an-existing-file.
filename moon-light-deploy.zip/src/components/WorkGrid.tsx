import { useState } from 'react';
import { ArrowUpRight } from 'lucide-react';
import { PROJECTS, type CategorySlug, type ProjectItem } from '../data/portfolioData';
import { ProjectArtwork } from './ProjectArtwork';

interface WorkGridProps {
  onSelectProject: (slug: CategorySlug) => void;
}

interface WorkCardProps {
  project: ProjectItem;
  index: number;
  onSelect: (slug: CategorySlug) => void;
}

function WorkCard({ project, index, onSelect }: WorkCardProps) {
  const [spot, setSpot] = useState({ x: 50, y: 50, active: false });

  const handleMouseMove = (e: React.MouseEvent<HTMLButtonElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    setSpot({ x, y, active: true });
  };

  const handleMouseLeave = () => {
    setSpot((prev) => ({ ...prev, active: false }));
  };

  return (
    <button
      type="button"
      onClick={() => onSelect(project.slug)}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      data-project-slug={project.slug}
      data-testid={`work-card-${project.slug}`}
      style={{
        borderColor: spot.active ? project.accentColor : '#20233a',
        boxShadow: spot.active ? `0 18px 46px -18px ${project.accentGlow}` : 'none',
      }}
      className="group relative flex flex-col overflow-hidden border bg-[#10121a] text-left transition-all duration-300 ease-out hover:-translate-y-1 focus-visible:ring-2 focus-visible:ring-[#7482ff]"
    >
      {/* Cursor spotlight overlay */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 z-10 transition-opacity duration-300"
        style={{
          opacity: spot.active ? 1 : 0,
          background: `radial-gradient(360px circle at ${spot.x}% ${spot.y}%, ${project.accentGlow}, transparent 68%)`,
        }}
      />

      {/* Cinematic topic cover */}
      <div className="relative aspect-[16/10] w-full overflow-hidden border-b border-[#20233a]">
        <div className="h-full w-full transition-transform duration-500 ease-out group-hover:scale-[1.04]">
          <ProjectArtwork slug={project.slug} variant="card" alt={project.coverAlt} />
        </div>
      </div>

      {/* Card content */}
      <div className="relative z-20 flex flex-1 flex-col justify-between p-6 sm:p-8">
        <div>
          <div className="flex items-center justify-between gap-4">
            <span
              className="font-mono-label text-xs uppercase tracking-[0.2em]"
              style={{ color: project.accentColor }}
            >
              {project.tag}
            </span>
            <span className="font-mono-label text-xs tabular-nums text-[#9298b0]">
              0{index + 1}
            </span>
          </div>

          <h3 className="mt-3 font-display text-2xl sm:text-3xl font-bold uppercase tracking-tight text-[#e9ecf8] text-balance">
            {project.title}
          </h3>

          <p className="mt-3 text-sm sm:text-base text-[#9298b0] leading-relaxed">
            {project.shortDescription}
          </p>
        </div>

        <div className="mt-7 flex items-center gap-2 font-mono-label text-xs uppercase tracking-[0.18em] text-[#cfd8ff] transition-colors group-hover:text-[#e9ecf8]">
          <span>View project</span>
          <ArrowUpRight
            className="h-4 w-4 transition-transform duration-200 group-hover:translate-x-0.5 group-hover:-translate-y-0.5"
            aria-hidden="true"
          />
        </div>
      </div>
    </button>
  );
}

export function WorkGrid({ onSelectProject }: WorkGridProps) {
  return (
    <section
      id="work"
      aria-labelledby="work-heading"
      className="border-b border-[#20233a] bg-[#090a0f] py-20 sm:py-28"
    >
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="mb-12 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="font-mono-label text-xs uppercase tracking-[0.22em] text-[#9298b0]">
              Selected Categories
            </p>
            <h2
              id="work-heading"
              className="mt-3 font-display text-3xl sm:text-5xl font-bold uppercase tracking-tight text-[#e9ecf8]"
            >
              Work
            </h2>
          </div>
          <p className="max-w-md text-sm sm:text-base text-[#9298b0]">
            Four creative lanes built under the same nocturnal mood—sharp pacing, sound-first editing, and live play.
          </p>
        </div>

        <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
          {PROJECTS.map((project, index) => (
            <WorkCard
              key={project.slug}
              project={project}
              index={index}
              onSelect={onSelectProject}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
