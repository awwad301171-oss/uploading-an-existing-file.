import { calculateMoonPhase, getMoonLitPath } from '../utils/moonMath';

interface MoonPhaseWidgetProps {
  scrollProgress: number;
}

export function MoonPhaseWidget({ scrollProgress }: MoonPhaseWidgetProps) {
  const { illumination, phaseName } = calculateMoonPhase(scrollProgress);

  const r = 10;
  const cx = 12;
  const cy = 12;
  const litPath = getMoonLitPath(illumination, cx, cy, r);

  return (
    <aside
      data-testid="moon-phase-widget"
      aria-label={`Current scroll moon phase: ${phaseName}`}
      className="fixed bottom-4 right-4 z-30 flex items-center gap-2.5 border border-[#20233a] bg-[#10121a]/90 px-3 py-2 backdrop-blur-sm"
    >
      <svg
        width="20"
        height="20"
        viewBox="0 0 24 24"
        aria-hidden="true"
        className="shrink-0"
      >
        <circle
          cx={cx}
          cy={cy}
          r={r}
          fill="#090a0f"
          stroke="#20233a"
          strokeWidth="1"
        />
        <path d={litPath} fill="#cfd8ff" />
      </svg>
      <span className="font-mono-label text-[11px] uppercase tracking-[0.14em] text-[#cfd8ff] whitespace-nowrap">
        {phaseName}
      </span>
    </aside>
  );
}
