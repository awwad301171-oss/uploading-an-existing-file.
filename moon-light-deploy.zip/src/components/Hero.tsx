import { lazy, Suspense, useEffect, useState } from 'react';
import { ArrowDownRight, ArrowUpRight } from 'lucide-react';
import { SITE_IDENTITY } from '../data/portfolioData';
import { MoonSphere } from './MoonSphere';

const LazyStarfieldCanvas = lazy(() =>
  import('./StarfieldCanvas').then((m) => ({ default: m.StarfieldCanvas }))
);

interface HeroProps {
  reducedMotion: boolean;
  tabVisible: boolean;
  onSeeWork: () => void;
}

export function Hero({ reducedMotion, tabVisible, onSeeWork }: HeroProps) {
  const [mouseOffset, setMouseOffset] = useState({ nx: 0, ny: 0 });
  const [mountStarfield, setMountStarfield] = useState(false);

  useEffect(() => {
    // Lazy-mount starfield canvas shortly after initial mount so first paint stays instant
    const id = window.setTimeout(() => setMountStarfield(true), 60);
    return () => window.clearTimeout(id);
  }, []);

  const handleMouseMove = (e: React.MouseEvent<HTMLElement>) => {
    if (reducedMotion) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const nx = ((e.clientX - rect.left) / rect.width - 0.5) * 2;
    const ny = ((e.clientY - rect.top) / rect.height - 0.5) * 2;
    setMouseOffset({ nx, ny });
  };

  const handleMouseLeave = () => {
    setMouseOffset({ nx: 0, ny: 0 });
  };

  return (
    <section
      id="top"
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      className="relative overflow-hidden border-b border-[#20233a] bg-[#090a0f]"
    >
      {/* Starfield backdrop */}
      {mountStarfield && (
        <Suspense fallback={null}>
          <LazyStarfieldCanvas reducedMotion={reducedMotion} tabVisible={tabVisible} />
        </Suspense>
      )}

      {/* Subtle architectural night-sky hairline grid */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 bg-[linear-gradient(to_right,rgba(32,35,58,0.25)_1px,transparent_1px),linear-gradient(to_bottom,rgba(32,35,58,0.2)_1px,transparent_1px)] bg-[size:96px_96px] opacity-35"
      />

      <div className="relative z-10 mx-auto max-w-6xl px-4 py-16 sm:px-6 sm:py-24 lg:px-8 lg:py-28">
        <div className="grid grid-cols-1 items-center gap-12 lg:grid-cols-12 lg:gap-8">
          {/* Left column: Typography & Actions */}
          <div className="lg:col-span-7 flex flex-col items-start">
            <p className="mb-5 font-mono-label text-xs uppercase tracking-[0.22em] text-[#9298b0]">
              Night Sky Portfolio · @lunex_xone
            </p>

            <h1 className="font-display font-extrabold uppercase tracking-[-0.04em] leading-[1.02] text-[clamp(3.25rem,10vw,6.75rem)]">
              <span className="block text-[#e9ecf8]">{SITE_IDENTITY.heroHeadlineTop}</span>
              <span className="block text-outlined-moon">{SITE_IDENTITY.heroHeadlineBottom}</span>
            </h1>

            <p className="mt-6 max-w-xl text-base sm:text-lg text-[#9298b0] leading-relaxed">
              {SITE_IDENTITY.heroSubtitle}
            </p>

            <div className="mt-9 flex flex-wrap items-center gap-4">
              <button
                type="button"
                onClick={onSeeWork}
                className="inline-flex min-h-[48px] items-center gap-2.5 border border-[#7482ff] bg-[#7482ff] px-6 py-3 font-mono-label text-xs font-medium uppercase tracking-[0.16em] text-[#090a0f] whitespace-nowrap transition-all duration-200 hover:bg-[#cfd8ff] hover:border-[#cfd8ff]"
              >
                <span>{SITE_IDENTITY.primaryCtaLabel}</span>
                <ArrowDownRight className="h-4 w-4" aria-hidden="true" />
              </button>

              <a
                href={SITE_IDENTITY.tiktokProfileUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex min-h-[48px] items-center gap-2.5 border border-[#20233a] bg-[#10121a]/90 px-6 py-3 font-mono-label text-xs uppercase tracking-[0.16em] text-[#e9ecf8] whitespace-nowrap transition-colors duration-200 hover:border-[#cfd8ff] hover:text-[#cfd8ff]"
              >
                <span>{SITE_IDENTITY.secondaryCtaLabel}</span>
                <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
              </a>
            </div>
          </div>

          {/* Right column: Realistic Glowing Moon */}
          <div className="lg:col-span-5 flex items-center justify-center py-4 lg:py-0">
            <MoonSphere reducedMotion={reducedMotion} mouseOffset={mouseOffset} />
          </div>
        </div>
      </div>
    </section>
  );
}
