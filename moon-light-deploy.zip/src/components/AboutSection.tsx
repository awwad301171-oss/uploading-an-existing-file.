import { ABOUT_DISCIPLINES, SITE_IDENTITY } from '../data/portfolioData';

export function AboutSection() {
  return (
    <section
      id="about"
      aria-labelledby="about-heading"
      className="border-b border-[#20233a] bg-[#090a0f] py-20 sm:py-28"
    >
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-12 lg:grid-cols-12 lg:gap-12">
          {/* Left: Bio */}
          <div className="lg:col-span-5">
            <p className="font-mono-label text-xs uppercase tracking-[0.22em] text-[#9298b0]">
              Behind Moon Light
            </p>
            <h2
              id="about-heading"
              className="mt-3 font-display text-3xl sm:text-5xl font-bold uppercase tracking-tight text-[#e9ecf8]"
            >
              About
            </h2>
            <p className="mt-6 text-lg sm:text-xl text-[#cfd8ff] leading-relaxed">
              {SITE_IDENTITY.aboutBio}
            </p>
          </div>

          {/* Right: Four-row discipline list */}
          <div className="lg:col-span-7 border-t border-[#20233a]">
            {ABOUT_DISCIPLINES.map((row, idx) => (
              <div
                key={row.title}
                className="flex flex-col gap-2 border-b border-[#20233a] py-6 sm:flex-row sm:items-baseline sm:justify-between sm:gap-8"
              >
                <div className="flex items-baseline gap-4 shrink-0">
                  <span className="font-mono-label text-xs tabular-nums text-[#7482ff]">
                    0{idx + 1}
                  </span>
                  <h3 className="font-display text-lg font-bold uppercase tracking-tight text-[#e9ecf8]">
                    {row.title}
                  </h3>
                </div>
                <p className="text-sm sm:text-base text-[#9298b0] sm:text-right max-w-md">
                  {row.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
