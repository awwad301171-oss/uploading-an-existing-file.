import { useEffect, useRef, useState } from 'react';
import { ExternalLink, Globe, RotateCcw, Send, X } from 'lucide-react';
import {
  getNagiExpressionMeta,
  type GroundingSource,
  type NagiExpression,
} from '../utils/groundingUtils';
import { NagiAvatar2D } from './NagiAvatar2D';

interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  sources?: GroundingSource[];
  searchQueries?: string[];
  failed?: boolean;
}

interface MoonChatWidgetProps {
  reducedMotion?: boolean;
}

const INITIAL_GREETING: ChatMessage = {
  id: 'greeting',
  role: 'model',
  text: "Yo, I'm Nagi Shiro. Ask me to solve a coding/math problem, break down Moon Light's anime cuts & montages, or search the web live.",
};

const STARTER_PROMPTS = [
  'How does Moon Light edit anime cuts?',
  'What anime or football edit styles are trending in 2026?',
  'Help me solve a step-by-step math or coding problem',
] as const;

const TAP_REACTIONS = [
  "Locked in. Want beat-sync tips, mobile stream info, or a live Google search?",
  "Usually I take it easy, but Moon Light's 9:16 timeline rhythm is worth staying sharp for.",
  'Try switching the 3D Orbital Rig to Anime or Football mood while we talk.',
  "Web Search is wired to Gemini 4 Hydrogen—ask about anything fresh on the net.",
] as const;

export function MoonChatWidget({ reducedMotion = false }: MoonChatWidgetProps) {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([INITIAL_GREETING]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [useSearch, setUseSearch] = useState(true);
  const [expression, setExpression] = useState<NagiExpression>('calm');
  const [tapIndex, setTapIndex] = useState(0);
  const [lastPrompt, setLastPrompt] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const logRef = useRef<HTMLDivElement | null>(null);
  const inputRef = useRef<HTMLInputElement | null>(null);
  const expressionTimerRef = useRef<number | null>(null);

  useEffect(() => {
    return () => {
      if (expressionTimerRef.current !== null) {
        window.clearTimeout(expressionTimerRef.current);
      }
    };
  }, []);

  useEffect(() => {
    if (!open) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setOpen(false);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [open]);

  useEffect(() => {
    if (open) {
      inputRef.current?.focus();
    }
  }, [open]);

  useEffect(() => {
    const el = logRef.current;
    if (!el) return;
    if (messages.length > 1 || loading || error) {
      el.scrollTop = el.scrollHeight;
    } else {
      el.scrollTop = 0;
    }
  }, [messages, loading, error, open]);

  const setTemporaryExpression = (next: NagiExpression, durationMs = 2600) => {
    if (expressionTimerRef.current !== null) {
      window.clearTimeout(expressionTimerRef.current);
    }
    setExpression(next);
    expressionTimerRef.current = window.setTimeout(() => {
      setExpression('calm');
      expressionTimerRef.current = null;
    }, durationMs);
  };

  const handleAvatarTap = () => {
    if (loading) return;
    const line = TAP_REACTIONS[tapIndex % TAP_REACTIONS.length];
    setTapIndex((prev) => prev + 1);
    setTemporaryExpression('speaking', 2400);
    setMessages((prev) => [
      ...prev,
      {
        id: `nagi-tap-${Date.now()}`,
        role: 'model',
        text: line,
      },
    ]);
  };

  const sendMessageText = async (rawText: string, isRetry = false) => {
    const text = rawText.trim();
    if (!text || loading) return;

    if (expressionTimerRef.current !== null) {
      window.clearTimeout(expressionTimerRef.current);
      expressionTimerRef.current = null;
    }

    const baseMessages = isRetry
      ? messages.filter((m) => !m.failed)
      : messages.filter((m) => !m.failed);

    const userMsg: ChatMessage = {
      id: `u-${Date.now()}`,
      role: 'user',
      text,
    };

    const nextMessages = [...baseMessages, userMsg];
    setMessages(nextMessages);
    setLastPrompt(text);
    if (!isRetry) setInput('');
    setError(null);
    setLoading(true);
    setExpression(useSearch ? 'searching' : 'focused');

    try {
      // Exclude synthetic client-only greeting / tap quips before real user turns
      const apiMessages = nextMessages
        .filter((m) => m.id !== INITIAL_GREETING.id && !m.id.startsWith('nagi-tap-'))
        .map((m) => ({ role: m.role, text: m.text }));

      const res = await fetch('/api/chat', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: apiMessages,
          useSearch,
        }),
      });

      const rawText = await res.text();
      let payload: {
        reply?: string;
        sources?: GroundingSource[];
        searchQueries?: string[];
        error?: string;
      } = {};
      if (rawText) {
        try {
          payload = JSON.parse(rawText) as typeof payload;
        } catch {
          // Non-JSON response (e.g., proxy/auth HTML page)
        }
      }

      if (!res.ok || !payload.reply) {
        const proxyHint =
          res.status === 403 && !payload.error
            ? 'The preview proxy blocked /api/chat (HTTP 403) before it reached the backend—usually because third-party cookies are blocked in the embedded iframe. Open the app URL in a dedicated browser tab (or allow preview cookies) and ensure a valid GEMINI_API_KEY is set in Settings > Secrets.'
            : `Unable to reach Nagi Shiro right now (HTTP ${res.status}). Make sure the backend server is running and GEMINI_API_KEY is set in Settings > Secrets.`;
        throw new Error(payload.error || proxyHint);
      }

      const modelMsg: ChatMessage = {
        id: `m-${Date.now()}`,
        role: 'model',
        text: payload.reply,
        sources: Array.isArray(payload.sources) ? payload.sources : undefined,
        searchQueries: Array.isArray(payload.searchQueries) ? payload.searchQueries : undefined,
      };
      setMessages((prev) => [...prev, modelMsg]);
      setLastPrompt(null);
      setTemporaryExpression('speaking', 2800);
    } catch (err) {
      setMessages((prev) =>
        prev.map((m) => (m.id === userMsg.id ? { ...m, failed: true } : m))
      );
      setError(err instanceof Error ? err.message : 'Unable to send message.');
      setExpression('calm');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    void sendMessageText(input);
  };

  const handleReset = () => {
    if (expressionTimerRef.current !== null) {
      window.clearTimeout(expressionTimerRef.current);
      expressionTimerRef.current = null;
    }
    setMessages([INITIAL_GREETING]);
    setLastPrompt(null);
    setError(null);
    setInput('');
    setExpression('calm');
    inputRef.current?.focus();
  };

  const hasUserTurn = messages.some((m) => m.role === 'user');
  const showStarters = !hasUserTurn && !loading;
  const exprMeta = getNagiExpressionMeta(expression);

  return (
    <>
      {/* Launcher button anchored bottom-left (mirrors MoonPhaseWidget bottom-right) */}
      <button
        type="button"
        onClick={() => setOpen((prev) => !prev)}
        data-testid="chat-launcher"
        aria-expanded={open}
        aria-controls="moon-studio-chat-dialog"
        className="fixed bottom-4 left-4 z-30 inline-flex min-h-[44px] items-center gap-2.5 border border-[#20233a] bg-[#10121a]/80 py-1.5 pl-1.5 pr-3.5 text-left backdrop-blur-md transition-all hover:border-[#b57bff] hover:shadow-[0_0_18px_rgba(181,123,255,0.22)] focus-visible:outline focus-visible:outline-2 focus-visible:outline-[#b57bff]"
      >
        <NagiAvatar2D
          expression={expression}
          variant="launcher"
          reducedMotion={reducedMotion}
        />
        <span className="flex flex-col leading-tight whitespace-nowrap shrink-0">
          <span className="font-display text-[11px] font-bold uppercase tracking-tight text-[#e9ecf8]">
            Nagi Shiro
          </span>
          <span className="font-mono-label text-[9px] uppercase tracking-[0.16em] text-[#9298b0]">
            AI2D Assistant
          </span>
        </span>
      </button>

      {open && (
        <section
          id="moon-studio-chat-dialog"
          data-testid="chat-dialog"
          role="dialog"
          aria-label="Nagi Shiro AI2D Assistant"
          className="fixed bottom-[70px] left-4 z-40 flex max-h-[min(560px,calc(100vh-6rem))] w-[calc(100vw-2rem)] max-w-[580px] flex-col overflow-hidden border border-[#20233a] bg-[#10121a]/80 backdrop-blur-xl shadow-[0_24px_64px_rgba(4,5,10,0.85),0_0_32px_rgba(181,123,255,0.12)] sm:grid sm:grid-cols-[192px_minmax(0,1fr)]"
        >
          {/* Subtle night-sky atmospheric nebula & starfield overlay */}
          <div
            aria-hidden="true"
            className="pointer-events-none absolute inset-0 z-0 overflow-hidden"
          >
            <div
              className="absolute inset-0"
              style={{
                background:
                  'radial-gradient(circle at 88% 14%, rgba(181, 123, 255, 0.14), transparent 46%), radial-gradient(circle at 18% 82%, rgba(116, 130, 255, 0.12), transparent 50%)',
              }}
            />
            <span className="absolute right-[14%] top-[18%] h-[2px] w-[2px] bg-[#cfd8ff]/60" />
            <span className="absolute right-[32%] top-[10%] h-[1.5px] w-[1.5px] bg-[#b57bff]/70" />
            <span className="absolute left-[44%] top-[28%] h-[1.5px] w-[1.5px] bg-[#cfd8ff]/45" />
            <span className="absolute right-[22%] top-[52%] h-[2px] w-[2px] bg-[#cfd8ff]/35" />
            <span className="absolute left-[58%] bottom-[22%] h-[1.5px] w-[1.5px] bg-[#b57bff]/50" />
          </div>

          {/* Desktop 2D Character Stage (Left Pane) */}
          <div className="relative z-10 hidden sm:flex sm:h-full sm:flex-col sm:border-r sm:border-[#20233a]/90 sm:bg-[#090a0f]/75 sm:p-2.5">
            <NagiAvatar2D
              expression={expression}
              variant="stage"
              reducedMotion={reducedMotion}
              onTap={handleAvatarTap}
            />
          </div>

          {/* Right Pane: Header + Mobile Compact 2D Strip + Scrollable Thread + Composer */}
          <div className="relative z-10 flex min-h-0 flex-1 flex-col">
            {/* Header */}
            <div className="flex items-center justify-between gap-2 border-b border-[#20233a]/90 bg-[#090a0f]/55 px-3 py-2.5 sm:px-4">
              <div className="flex min-w-0 items-center gap-2.5">
                <div className="sm:hidden">
                  <NagiAvatar2D
                    expression={expression}
                    variant="compact"
                    reducedMotion={reducedMotion}
                    onTap={handleAvatarTap}
                  />
                </div>
                <div className="min-w-0">
                  <p className="truncate font-mono-label text-[10px] uppercase tracking-[0.14em] text-[#9298b0]">
                    <span className="hidden sm:inline">Moon Light · </span>
                    <span style={{ color: exprMeta.accent }}>{exprMeta.label}</span>
                  </p>
                  <h2 className="truncate font-display text-xs sm:text-sm font-bold uppercase tracking-tight text-[#e9ecf8]">
                    Nagi Shiro
                  </h2>
                </div>
              </div>

              <div className="flex shrink-0 items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => setUseSearch((prev) => !prev)}
                  data-testid="chat-search-toggle"
                  aria-pressed={useSearch}
                  title="Toggle Google Search grounding"
                  className="inline-flex min-h-[34px] items-center gap-1.5 border px-2 py-1 font-mono-label text-[10px] uppercase tracking-[0.12em] whitespace-nowrap transition-colors"
                  style={{
                    borderColor: useSearch ? '#4fb0ff' : '#20233a',
                    backgroundColor: useSearch ? '#131b2b' : '#090a0f',
                    color: useSearch ? '#4fb0ff' : '#9298b0',
                  }}
                >
                  <Globe className="h-3 w-3 shrink-0" aria-hidden="true" />
                  <span>{useSearch ? 'Web On' : 'Web Off'}</span>
                </button>

                <button
                  type="button"
                  onClick={handleReset}
                  aria-label="Reset conversation"
                  title="Reset conversation"
                  className="inline-flex min-h-[34px] min-w-[34px] items-center justify-center border border-[#20233a] bg-[#090a0f] text-[#9298b0] transition-colors hover:border-[#7482ff] hover:text-[#e9ecf8]"
                >
                  <RotateCcw className="h-3.5 w-3.5" aria-hidden="true" />
                </button>

                <button
                  type="button"
                  onClick={() => setOpen(false)}
                  aria-label="Close Nagi Shiro Assistant"
                  className="inline-flex min-h-[34px] min-w-[34px] items-center justify-center border border-[#20233a] bg-[#090a0f] text-[#9298b0] transition-colors hover:border-[#7482ff] hover:text-[#e9ecf8]"
                >
                  <X className="h-4 w-4" aria-hidden="true" />
                </button>
              </div>
            </div>

            {/* Scrollable conversation thread */}
            <div
              ref={logRef}
              role="log"
              aria-live="polite"
              data-testid="chat-message-log"
              className="flex min-h-[210px] flex-1 flex-col gap-3 overflow-y-auto p-3.5 sm:p-4"
            >
              {messages.map((msg) => {
                const isUser = msg.role === 'user';
                const isActiveUser = isUser && !msg.failed;
                return (
                  <div
                    key={msg.id}
                    data-active-user={isActiveUser ? 'true' : undefined}
                    className={`max-w-[90%] border px-3.5 py-2.5 text-sm leading-relaxed transition-all ${
                      isActiveUser
                        ? 'self-end border-[#b57bff]/85 bg-[#191329]/85 text-[#e9ecf8] shadow-[0_0_20px_rgba(181,123,255,0.28),inset_0_0_14px_rgba(181,123,255,0.12)]'
                        : isUser
                        ? 'self-end border-[#ff6b8a]/65 bg-[#1f121b]/85 text-[#ffd7e0]'
                        : 'self-start border-[#20233a]/90 border-t-[#cfd8ff]/20 bg-[#090a0f]/75 text-[#cfd8ff]'
                    }`}
                  >
                    <p
                      className={`mb-1 font-mono-label text-[10px] uppercase tracking-[0.16em] ${
                        isActiveUser
                          ? 'text-[#d8b4fe]'
                          : isUser
                          ? 'text-[#ff9fb3]'
                          : 'text-[#9298b0]'
                      }`}
                    >
                      {isUser ? (msg.failed ? 'You · Not Sent' : 'You') : 'Nagi Shiro'}
                    </p>
                    <p className="whitespace-pre-wrap">{msg.text}</p>

                    {msg.searchQueries && msg.searchQueries.length > 0 && (
                      <p className="mt-2 border-t border-[#20233a] pt-2 font-mono-label text-[10px] text-[#9298b0]">
                        Searched: {msg.searchQueries.join(' · ')}
                      </p>
                    )}

                    {msg.sources && msg.sources.length > 0 && (
                      <div className="mt-2 border-t border-[#20233a] pt-2">
                        <p className="mb-1.5 font-mono-label text-[10px] uppercase tracking-[0.14em] text-[#4fb0ff]">
                          Sources
                        </p>
                        <ul className="flex flex-col gap-1">
                          {msg.sources.map((src) => (
                            <li key={src.url}>
                              <a
                                href={src.url}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="inline-flex max-w-full items-center gap-1.5 text-xs text-[#cfd8ff] underline-offset-4 hover:text-[#4fb0ff] hover:underline"
                              >
                                <span className="truncate">{src.title}</span>
                                <span className="shrink-0 font-mono-label text-[10px] text-[#9298b0]">
                                  ({src.domain})
                                </span>
                                <ExternalLink className="h-3 w-3 shrink-0" aria-hidden="true" />
                              </a>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                );
              })}

              {loading && (
                <div
                  data-testid="chat-loading"
                  className="self-start border border-[#20233a] bg-[#090a0f] px-3.5 py-2.5 font-mono-label text-[11px] uppercase tracking-[0.16em] text-[#4fb0ff]"
                >
                  {useSearch ? 'Searching web & thinking...' : 'Thinking...'}
                </div>
              )}

              {showStarters && (
                <div className="mt-1 flex flex-col gap-2">
                  <p className="font-mono-label text-[10px] uppercase tracking-[0.16em] text-[#9298b0]">
                    Suggested Prompts
                  </p>
                  {STARTER_PROMPTS.map((prompt) => (
                    <button
                      key={prompt}
                      type="button"
                      onClick={() => void sendMessageText(prompt)}
                      className="border border-[#20233a]/90 bg-[#090a0f]/70 px-3 py-2 text-left text-xs text-[#cfd8ff] transition-all hover:border-[#b57bff]/80 hover:bg-[#191329]/60 hover:text-[#e9ecf8] hover:shadow-[0_0_14px_rgba(181,123,255,0.18)]"
                    >
                      {prompt}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {error && (
              <div
                role="alert"
                data-testid="chat-error"
                className="flex items-start justify-between gap-2 border-t border-[#ff6b8a]/50 bg-[#1a0f16]/85 px-4 py-2.5 text-xs text-[#ffb0c0] backdrop-blur-sm"
              >
                <span className="leading-relaxed">{error}</span>
                {lastPrompt && !loading && (
                  <button
                    type="button"
                    onClick={() => void sendMessageText(lastPrompt, true)}
                    className="shrink-0 border border-[#ff6b8a]/60 bg-[#090a0f] px-2.5 py-1 font-mono-label text-[10px] uppercase tracking-[0.12em] text-[#ffd1dc] transition-colors hover:border-[#ff6b8a]"
                  >
                    Retry
                  </button>
                )}
              </div>
            )}

            {/* Input composer */}
            <form
              onSubmit={handleSubmit}
              className="flex items-center gap-2 border-t border-[#20233a]/90 bg-[#090a0f]/60 p-3"
            >
              <label htmlFor="moon-chat-input" className="sr-only">
                Ask Nagi Shiro AI2D Assistant
              </label>
              <input
                ref={inputRef}
                id="moon-chat-input"
                data-testid="chat-input"
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder={
                  useSearch
                    ? 'Ask Nagi or search live web...'
                    : 'Ask Nagi about edits & studio...'
                }
                disabled={loading}
                className="min-h-[40px] flex-1 border border-[#20233a] bg-[#090a0f]/80 px-3 text-sm text-[#e9ecf8] placeholder:text-[#9298b0] transition-shadow focus:border-[#b57bff] focus:shadow-[0_0_16px_rgba(181,123,255,0.22)] focus:outline-none disabled:opacity-60"
              />
              <button
                type="submit"
                data-testid="chat-send"
                disabled={loading || !input.trim()}
                aria-label="Send message"
                className="inline-flex min-h-[40px] min-w-[40px] items-center justify-center border border-[#b57bff] bg-[#b57bff] px-3 text-[#090a0f] shadow-[0_0_16px_rgba(181,123,255,0.3)] transition-all hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-45 disabled:shadow-none"
              >
                <Send className="h-4 w-4" aria-hidden="true" />
              </button>
            </form>
          </div>
        </section>
      )}
    </>
  );
}
