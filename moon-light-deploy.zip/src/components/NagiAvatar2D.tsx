import { useState } from 'react';
import { motion } from 'motion/react';
import nagiShiroPortrait from '../assets/images/nagi_shiro_ai2d_1794780630297.jpg';
import { getNagiExpressionMeta, type NagiExpression } from '../utils/groundingUtils';

interface NagiAvatar2DProps {
  expression: NagiExpression;
  variant: 'launcher' | 'compact' | 'stage';
  reducedMotion: boolean;
  onTap?: () => void;
}

function NagiSvgFallback({ accent }: { accent: string }) {
  return (
    <svg
      viewBox="0 0 240 320"
      className="h-full w-full bg-[#090a0f]"
      aria-hidden="true"
    >
      <defs>
        <radialGradient id="nagi-moon-halo" cx="50%" cy="32%" r="60%">
          <stop offset="0%" stopColor={accent} stopOpacity="0.35" />
          <stop offset="100%" stopColor="#090a0f" stopOpacity="0" />
        </radialGradient>
      </defs>
      <rect width="240" height="320" fill="#090a0f" />
      <rect width="240" height="320" fill="url(#nagi-moon-halo)" />
      {/* Stylized anime silver hair + dark hoodie silhouette */}
      <path
        d="M45 320 C48 232 76 206 120 206 C164 206 192 232 195 320 Z"
        fill="#12141e"
        stroke="#2a2f4d"
        strokeWidth="2"
      />
      <circle cx="120" cy="128" r="46" fill="#cfd8ff" fillOpacity="0.92" />
      <path
        d="M68 134 C66 80 94 56 122 58 C154 58 176 82 172 134 C162 110 144 96 120 98 C96 96 78 110 68 134 Z"
        fill="#e9ecf8"
      />
      <line x1="98" y1="132" x2="112" y2="132" stroke="#10121a" strokeWidth="3" />
      <line x1="128" y1="132" x2="142" y2="132" stroke="#10121a" strokeWidth="3" />
    </svg>
  );
}

export function NagiAvatar2D({
  expression,
  variant,
  reducedMotion,
  onTap,
}: NagiAvatar2DProps) {
  const [imageError, setImageError] = useState(false);
  const [tilt, setTilt] = useState({ x: 0, y: 0 });
  const meta = getNagiExpressionMeta(expression);

  if (variant === 'launcher') {
    return (
      <span className="relative block h-7 w-7 shrink-0 overflow-hidden border border-[#20233a] bg-[#090a0f]">
        {imageError ? (
          <NagiSvgFallback accent={meta.accent} />
        ) : (
          <img
            src={nagiShiroPortrait}
            alt="Nagi Shiro"
            referrerPolicy="no-referrer"
            onError={() => setImageError(true)}
            className="h-full w-full object-cover object-top"
          />
        )}
      </span>
    );
  }

  if (variant === 'compact') {
    return (
      <button
        type="button"
        onClick={onTap}
        aria-label="Interact with Nagi Shiro 2D avatar"
        className="relative h-12 w-11 shrink-0 overflow-hidden border border-[#20233a] bg-[#090a0f] focus-visible:outline focus-visible:outline-2 focus-visible:outline-[#7482ff]"
        style={{ boxShadow: `inset 0 0 18px ${meta.accent}24` }}
      >
        <motion.div
          animate={
            reducedMotion
              ? undefined
              : {
                  y: expression === 'speaking' ? [0, -2, 0] : [0, -1.5, 0],
                }
          }
          transition={
            reducedMotion
              ? undefined
              : {
                  duration: expression === 'speaking' ? 0.8 : 3.2,
                  repeat: Infinity,
                  ease: 'easeInOut',
                }
          }
          className="h-full w-full"
        >
          {imageError ? (
            <NagiSvgFallback accent={meta.accent} />
          ) : (
            <img
              src={nagiShiroPortrait}
              alt="Nagi Shiro AI2D assistant portrait"
              referrerPolicy="no-referrer"
              onError={() => setImageError(true)}
              className="h-full w-full object-cover object-top"
            />
          )}
        </motion.div>
        {expression === 'searching' && !reducedMotion && (
          <motion.div
            aria-hidden="true"
            animate={{ y: [-12, 68] }}
            transition={{ duration: 1.3, repeat: Infinity, ease: 'linear' }}
            className="pointer-events-none absolute inset-x-0 h-[2px]"
            style={{ backgroundColor: meta.accent, opacity: 0.75 }}
          />
        )}
      </button>
    );
  }

  const handlePointerMove = (e: React.PointerEvent<HTMLButtonElement>) => {
    if (reducedMotion) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const nx = ((e.clientX - rect.left) / rect.width - 0.5) * 2;
    const ny = ((e.clientY - rect.top) / rect.height - 0.5) * 2;
    setTilt({ x: nx * 5, y: ny * 4 });
  };

  return (
    <button
      type="button"
      onClick={onTap}
      onPointerMove={handlePointerMove}
      onPointerLeave={() => setTilt({ x: 0, y: 0 })}
      data-testid="nagi-2d-stage"
      aria-label="Interact with Nagi Shiro 2D character stage"
      className="group relative flex h-full w-full flex-col overflow-hidden border border-[#20233a] bg-[#090a0f] text-left focus-visible:outline focus-visible:outline-2 focus-visible:outline-[#7482ff]"
    >
      {/* Subtle nocturnal moonlight rim glow tuned to Nagi's state */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 transition-opacity duration-300"
        style={{
          background: `radial-gradient(circle at 50% 24%, ${meta.accent}2e, rgba(9, 10, 15, 0.05) 68%)`,
        }}
      />

      {/* Precision vector corner reticles */}
      <svg
        viewBox="0 0 180 260"
        preserveAspectRatio="none"
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 z-10 h-full w-full"
      >
        <path d="M10 20 V10 H20" fill="none" stroke={meta.accent} strokeOpacity="0.7" strokeWidth="1.5" />
        <path d="M160 10 H170 V20" fill="none" stroke={meta.accent} strokeOpacity="0.7" strokeWidth="1.5" />
        <path d="M10 240 V250 H20" fill="none" stroke={meta.accent} strokeOpacity="0.45" strokeWidth="1.5" />
        <path d="M160 250 H170 V240" fill="none" stroke={meta.accent} strokeOpacity="0.45" strokeWidth="1.5" />
      </svg>

      {/* Live 2D motion rig wrapper */}
      <div className="relative flex-1 w-full overflow-hidden">
        <motion.div
          animate={
            reducedMotion
              ? undefined
              : {
                  y: expression === 'speaking' ? [0, -3, 0] : [0, -4, 0],
                  rotate: tilt.x * 0.25,
                  x: tilt.x,
                }
          }
          transition={
            reducedMotion
              ? undefined
              : {
                  y: {
                    duration: expression === 'speaking' ? 0.9 : 3.8,
                    repeat: Infinity,
                    ease: 'easeInOut',
                  },
                  x: { type: 'spring', stiffness: 180, damping: 22 },
                  rotate: { type: 'spring', stiffness: 180, damping: 22 },
                }
          }
          className="h-full w-full"
        >
          {imageError ? (
            <NagiSvgFallback accent={meta.accent} />
          ) : (
            <img
              src={nagiShiroPortrait}
              alt="Nagi Shiro AI2D assistant character portrait"
              referrerPolicy="no-referrer"
              onError={() => setImageError(true)}
              className="h-full w-full object-cover object-top transition-transform duration-300 group-hover:scale-[1.03]"
            />
          )}
        </motion.div>

        {/* Grounded search sweep line */}
        {expression === 'searching' && !reducedMotion && (
          <motion.div
            aria-hidden="true"
            animate={{ y: [-10, 260] }}
            transition={{ duration: 1.5, repeat: Infinity, ease: 'linear' }}
            className="pointer-events-none absolute inset-x-0 z-10 h-[2px]"
            style={{
              background: `linear-gradient(90deg, transparent, ${meta.accent}, transparent)`,
            }}
          />
        )}

        {/* Measured bottom gradient scrim for caption contrast */}
        <div
          aria-hidden="true"
          className="pointer-events-none absolute inset-x-0 bottom-0 h-24 bg-gradient-to-t from-[#090a0f] via-[#090a0f]/75 to-transparent"
        />
      </div>

      {/* Stage footer readout (clean unboxed text + speaking cadence bars) */}
      <div className="relative z-10 border-t border-[#20233a] bg-[#090a0f]/95 px-3 py-2.5">
        <div className="flex items-center justify-between gap-2">
          <span className="font-mono-label text-[10px] uppercase tracking-[0.16em] text-[#e9ecf8]">
            Nagi Shiro
          </span>
          <span
            className="font-mono-label text-[10px] uppercase tracking-[0.14em]"
            style={{ color: meta.accent }}
          >
            {meta.label}
          </span>
        </div>

        {/* Minimal 2D speaking cadence strip */}
        <div className="mt-2 flex h-3 items-end gap-1" aria-hidden="true">
          {[0.38, 0.72, 1, 0.62, 0.44].map((base, idx) => (
            <motion.span
              key={idx}
              className="block w-1.5 origin-bottom"
              style={{
                height: '12px',
                backgroundColor:
                  expression === 'speaking' || expression === 'searching'
                    ? meta.accent
                    : '#20233a',
              }}
              animate={
                !reducedMotion && (expression === 'speaking' || expression === 'searching')
                  ? { scaleY: [base * 0.35, base, base * 0.45] }
                  : { scaleY: base * 0.35 }
              }
              transition={
                !reducedMotion && (expression === 'speaking' || expression === 'searching')
                  ? {
                      duration: 0.42 + idx * 0.08,
                      repeat: Infinity,
                      repeatType: 'reverse',
                      ease: 'easeInOut',
                    }
                  : { duration: 0.2 }
              }
            />
          ))}
          <span className="ml-auto font-mono-label text-[9px] uppercase tracking-[0.14em] text-[#9298b0]">
            Tap 2D
          </span>
        </div>
      </div>
    </button>
  );
}
