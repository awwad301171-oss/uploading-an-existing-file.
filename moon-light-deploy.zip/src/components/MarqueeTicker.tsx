import { MARQUEE_ITEMS } from '../data/portfolioData';

interface MarqueeTickerProps {
  reducedMotion: boolean;
  tabVisible: boolean;
}

export function MarqueeTicker({ reducedMotion, tabVisible }: MarqueeTickerProps) {
  const paused = reducedMotion || !tabVisible;

  const renderTrack = (keyPrefix: string) =>
    MARQUEE_ITEMS.map((item, idx) => (
      <span
        key={`${keyPrefix}-${idx}`}
        className="inline-flex items-center gap-6 px-6 font-display text-xs sm:text-sm font-semibold uppercase tracking-[0.18em] text-[#cfd8ff] whitespace-nowrap"
      >
        <span style={{ color: item.color }}>{item.label}</span>
        <span aria-hidden="true" className="text-[#20233a]">
          /
        </span>
      </span>
    ));

  return (
    <div
      aria-label="Content disciplines"
      className="relative overflow-hidden border-b border-[#20233a] bg-[#10121a] py-4 select-none"
    >
      {reducedMotion ? (
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-center gap-y-2 px-4">
          {renderTrack('static')}
        </div>
      ) : (
        <div
          className={`flex w-max ${
            paused ? 'animate-marquee animate-marquee-paused' : 'animate-marquee'
          }`}
        >
          <div className="flex shrink-0 items-center">{renderTrack('a')}</div>
          <div className="flex shrink-0 items-center" aria-hidden="true">
            {renderTrack('b')}
          </div>
          <div className="flex shrink-0 items-center" aria-hidden="true">
            {renderTrack('c')}
          </div>
        </div>
      )}
    </div>
  );
}
