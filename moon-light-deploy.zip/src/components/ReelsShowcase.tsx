import { useRef, useState } from 'react';
import { ArrowLeft, ArrowRight, Play } from 'lucide-react';
import { REELS_SHOWCASE, SITE_IDENTITY, type ReelCardItem } from '../data/portfolioData';

function ReelPatternArt({ item }: { item: ReelCardItem }) {
  return (
    <div
      className="absolute inset-0"
      style={{
        background: `radial-gradient(circle at 30% 20%, ${item.accentColor}38, transparent 58%), radial-gradient(circle at 80% 80%, ${item.secondaryColor}26, #090a0f 75%)`,
      }}
    >
      <svg
        viewBox="0 0 270 480"
        preserveAspectRatio="xMidYMid slice"
        className="h-full w-full opacity-80"
        aria-hidden="true"
      >
        {item.pattern === 'slash' && (
          <>
            <path d="M 20 380 L 145 210 L 250 90" stroke={item.accentColor} strokeWidth="2.5" fill="none" />
            <path d="M 50 420 L 175 240 L 260 140" stroke="#cfd8ff" strokeOpacity="0.35" strokeWidth="1" fill="none" />
            <circle cx="195" cy="145" r="46" fill={item.accentColor} fillOpacity="0.14" stroke={item.accentColor} strokeOpacity="0.45" />
          </>
        )}
        {item.pattern === 'pitch' && (
          <>
            <line x1="0" y1="310" x2="270" y2="310" stroke={item.accentColor} strokeOpacity="0.45" />
            <ellipse cx="135" cy="310" rx="70" ry="24" fill="none" stroke={item.accentColor} strokeOpacity="0.55" />
            <path d="M 35 370 Q 135 120 225 180" fill="none" stroke={item.accentColor} strokeDasharray="6 5" strokeWidth="2" />
          </>
        )}
        {item.pattern === 'reticle' && (
          <>
            <circle cx="135" cy="210" r="64" fill="none" stroke={item.accentColor} strokeOpacity="0.5" strokeWidth="1.5" />
            <circle cx="135" cy="210" r="24" fill="none" stroke="#cfd8ff" strokeOpacity="0.7" />
            <line x1="50" y1="210" x2="96" y2="210" stroke={item.accentColor} strokeWidth="2" />
            <line x1="174" y1="210" x2="220" y2="210" stroke={item.accentColor} strokeWidth="2" />
          </>
        )}
        {item.pattern === 'wave' && (
          <>
            {[46, 84, 122].map((r, i) => (
              <circle key={r} cx="135" cy="200" r={r} fill="none" stroke={item.accentColor} strokeOpacity={0.55 - i * 0.14} />
            ))}
            {Array.from({ length: 14 }).map((_, i) => {
              const x = 35 + i * 15;
              const h = 18 + Math.abs(Math.sin(i * 0.8)) * 56;
              return (
                <line
                  key={i}
                  x1={x}
                  y1={360 - h / 2}
                  x2={x}
                  y2={360 + h / 2}
                  stroke={item.accentColor}
                  strokeOpacity="0.75"
                  strokeWidth="2"
                />
              );
            })}
          </>
        )}
        {item.pattern === 'eclipse' && (
          <>
            <circle cx="135" cy="185" r="58" fill="#090a0f" stroke={item.accentColor} strokeOpacity="0.7" strokeWidth="2" />
            <circle cx="145" cy="176" r="54" fill={item.accentColor} fillOpacity="0.16" />
          </>
        )}
        {item.pattern === 'prism' && (
          <>
            <polygon points="135,90 220,270 50,270" fill="none" stroke={item.accentColor} strokeOpacity="0.6" strokeWidth="1.5" />
            <line x1="15" y1="210" x2="112" y2="185" stroke="#cfd8ff" strokeOpacity="0.55" strokeWidth="1.5" />
            <line x1="168" y1="185" x2="258" y2="235" stroke={item.accentColor} strokeWidth="2" />
          </>
        )}
      </svg>
    </div>
  );
}

export function ReelsShowcase() {
  const scrollerRef = useRef<HTMLDivElement | null>(null);
  const dragState = useRef({ isDown: false, startX: 0, scrollLeft: 0, moved: false });
  const [dragging, setDragging] = useState(false);

  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    const el = scrollerRef.current;
    if (!el) return;
    dragState.current = {
      isDown: true,
      startX: e.clientX,
      scrollLeft: el.scrollLeft,
      moved: false,
    };
    setDragging(true);
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    const el = scrollerRef.current;
    if (!el || !dragState.current.isDown) return;
    const dx = e.clientX - dragState.current.startX;
    if (Math.abs(dx) > 6) {
      dragState.current.moved = true;
    }
    el.scrollLeft = dragState.current.scrollLeft - dx;
  };

  const handlePointerUp = () => {
    dragState.current.isDown = false;
    setDragging(false);
    window.setTimeout(() => {
      dragState.current.moved = false;
    }, 60);
  };

  const handleCardClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
    if (dragState.current.moved) {
      e.preventDefault();
    }
  };

  const scrollByStep = (direction: -1 | 1) => {
    const el = scrollerRef.current;
    if (!el) return;
    el.scrollBy({ left: direction * 300, behavior: 'smooth' });
  };

  return (
    <section
      id="reels"
      aria-labelledby="reels-heading"
      className="border-b border-[#20233a] bg-[#090a0f] py-20 sm:py-28"
    >
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="mb-10 flex flex-col gap-6 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="font-mono-label text-xs uppercase tracking-[0.22em] text-[#9298b0]">
              Vertical Feed · 9:16
            </p>
            <h2
              id="reels-heading"
              className="mt-3 font-display text-3xl sm:text-5xl font-bold uppercase tracking-tight text-[#e9ecf8]"
            >
              Reels Showcase
            </h2>
          </div>

          <div className="flex items-center gap-3">
            <span className="hidden sm:inline font-mono-label text-xs uppercase tracking-[0.16em] text-[#9298b0] mr-2">
              Drag or click to open TikTok
            </span>
            <button
              type="button"
              onClick={() => scrollByStep(-1)}
              aria-label="Scroll reels left"
              className="inline-flex min-h-[44px] min-w-[44px] items-center justify-center border border-[#20233a] bg-[#10121a] text-[#cfd8ff] transition-colors hover:border-[#7482ff] hover:text-[#e9ecf8]"
            >
              <ArrowLeft className="h-4 w-4" aria-hidden="true" />
            </button>
            <button
              type="button"
              onClick={() => scrollByStep(1)}
              aria-label="Scroll reels right"
              className="inline-flex min-h-[44px] min-w-[44px] items-center justify-center border border-[#20233a] bg-[#10121a] text-[#cfd8ff] transition-colors hover:border-[#7482ff] hover:text-[#e9ecf8]"
            >
              <ArrowRight className="h-4 w-4" aria-hidden="true" />
            </button>
          </div>
        </div>

        {/* Horizontal drag-to-scroll carousel */}
        <div
          ref={scrollerRef}
          data-testid="reels-carousel"
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          onPointerLeave={handlePointerUp}
          onPointerCancel={handlePointerUp}
          className={`flex gap-5 overflow-x-auto pb-4 select-none [scrollbar-width:none] [&::-webkit-scrollbar]:hidden ${
            dragging ? 'cursor-grabbing' : 'cursor-grab'
          }`}
        >
          {REELS_SHOWCASE.map((item) => (
            <a
              key={item.id}
              href={SITE_IDENTITY.tiktokProfileUrl}
              target="_blank"
              rel="noopener noreferrer"
              onClick={handleCardClick}
              draggable={false}
              aria-label={`Watch ${item.title} (${item.categoryLabel}) on TikTok`}
              className="group relative aspect-[9/16] w-[220px] sm:w-[250px] shrink-0 overflow-hidden border border-[#20233a] bg-[#10121a] transition-all duration-300 hover:-translate-y-1 hover:border-[#7482ff]"
            >
              <ReelPatternArt item={item} />

              {/* Subtle bottom gradient scrim for legible text */}
              <div
                aria-hidden="true"
                className="absolute inset-0 bg-gradient-to-t from-[#090a0f] via-[#090a0f]/30 to-transparent"
              />

              {/* Top phone frame header */}
              <div className="relative z-10 flex items-center justify-between p-4">
                <span
                  className="font-mono-label text-[11px] uppercase tracking-[0.18em]"
                  style={{ color: item.accentColor }}
                >
                  {item.categoryLabel}
                </span>
                <span className="font-mono-label text-[11px] tabular-nums text-[#9298b0]">
                  {item.duration}
                </span>
              </div>

              {/* Center play affordance */}
              <div className="absolute inset-0 z-10 flex items-center justify-center">
                <span className="flex h-12 w-12 items-center justify-center border border-[#cfd8ff]/45 bg-[#090a0f]/75 text-[#e9ecf8] transition-all duration-200 group-hover:scale-110 group-hover:border-[#cfd8ff] group-hover:bg-[#7482ff] group-hover:text-[#090a0f]">
                  <Play className="h-4 w-4 fill-current ml-0.5" aria-hidden="true" />
                </span>
              </div>

              {/* Bottom caption */}
              <div className="absolute inset-x-0 bottom-0 z-10 p-4">
                <p className="font-display text-sm font-bold uppercase tracking-tight text-[#e9ecf8]">
                  {item.title}
                </p>
                <p className="mt-1 font-mono-label text-[11px] uppercase tracking-[0.14em] text-[#9298b0]">
                  @lunex_xone · TikTok
                </p>
              </div>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}
