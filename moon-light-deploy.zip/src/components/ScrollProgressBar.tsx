interface ScrollProgressBarProps {
  progress: number;
  accentColor: string;
  reducedMotion?: boolean;
}

export function ScrollProgressBar({
  progress,
  accentColor,
  reducedMotion = false,
}: ScrollProgressBarProps) {
  const clamped = Math.max(0, Math.min(1, Number.isFinite(progress) ? progress : 0));
  const percent = Math.round(clamped * 100);

  return (
    <div
      data-testid="scroll-progress-bar"
      data-accent-color={accentColor}
      role="progressbar"
      aria-label="Page scroll depth"
      aria-valuemin={0}
      aria-valuemax={100}
      aria-valuenow={percent}
      className="pointer-events-none fixed left-0 right-0 top-0 z-[55] h-[3px] bg-[#20233a]/45"
    >
      <div
        data-testid="scroll-progress-fill"
        className={`h-full w-full origin-left ${
          reducedMotion ? '' : 'transition-[background-color,box-shadow] duration-300 ease-out'
        }`}
        style={{
          transform: `scaleX(${clamped.toFixed(4)})`,
          backgroundColor: accentColor,
          boxShadow: clamped > 0.01 ? `0 0 10px ${accentColor}` : 'none',
        }}
      />
    </div>
  );
}
