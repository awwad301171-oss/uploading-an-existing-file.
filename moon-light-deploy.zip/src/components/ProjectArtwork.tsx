import { useState } from 'react';
import type { CategorySlug } from '../data/portfolioData';
import { TOPIC_COVER_IMAGES } from '../data/topicImages';

interface ProjectArtworkProps {
  slug: CategorySlug;
  variant?: 'card' | 'banner';
  alt?: string;
}

function ProceduralFallback({ slug, isBanner }: { slug: CategorySlug; isBanner: boolean }) {
  if (slug === 'anime-edits') {
    return (
      <div className="relative h-full w-full overflow-hidden bg-[#0b0a14]">
        <div
          className="absolute inset-0"
          style={{
            background:
              'radial-gradient(circle at 72% 28%, rgba(181, 123, 255, 0.34), rgba(116, 130, 255, 0.1) 45%, rgba(9, 10, 15, 0.96) 80%)',
          }}
        />
        <svg
          viewBox={isBanner ? '0 0 1200 480' : '0 0 640 400'}
          preserveAspectRatio="xMidYMid slice"
          className="h-full w-full"
          aria-hidden="true"
        >
          <defs>
            <linearGradient id="anime-slash" x1="0%" y1="100%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#b57bff" stopOpacity="0" />
              <stop offset="50%" stopColor="#b57bff" stopOpacity="0.95" />
              <stop offset="100%" stopColor="#cfd8ff" stopOpacity="0.9" />
            </linearGradient>
          </defs>
          {/* Crescent eclipse silhouette */}
          <circle
            cx={isBanner ? 860 : 450}
            cy={isBanner ? 190 : 150}
            r={isBanner ? 130 : 92}
            fill="none"
            stroke="#b57bff"
            strokeOpacity="0.35"
            strokeWidth="1.5"
          />
          <circle
            cx={isBanner ? 860 : 450}
            cy={isBanner ? 190 : 150}
            r={isBanner ? 88 : 62}
            fill="#b57bff"
            fillOpacity="0.12"
          />
          {/* Cinematic frame guides */}
          <rect
            x={isBanner ? 90 : 48}
            y={isBanner ? 72 : 52}
            width={isBanner ? 1020 : 544}
            height={isBanner ? 336 : 296}
            fill="none"
            stroke="#20233a"
            strokeWidth="1"
          />
          {/* Kinetic katana / speed-ramp diagonal slash */}
          <path
            d={
              isBanner
                ? 'M 140 390 L 660 220 L 1060 95'
                : 'M 72 330 L 350 185 L 568 74'
            }
            stroke="url(#anime-slash)"
            strokeWidth="3"
            fill="none"
          />
          <path
            d={
              isBanner
                ? 'M 220 420 L 720 250 L 1110 135'
                : 'M 110 360 L 400 205 L 590 112'
            }
            stroke="#cfd8ff"
            strokeOpacity="0.32"
            strokeWidth="1"
            fill="none"
          />
          {/* Beat timeline ticks */}
          {Array.from({ length: 18 }).map((_, i) => {
            const x = (isBanner ? 110 : 64) + i * (isBanner ? 58 : 30);
            const h = i % 4 === 0 ? 34 : i % 2 === 0 ? 20 : 11;
            const yBase = isBanner ? 380 : 326;
            return (
              <line
                key={i}
                x1={x}
                y1={yBase}
                x2={x}
                y2={yBase - h}
                stroke={i % 4 === 0 ? '#b57bff' : '#7482ff'}
                strokeOpacity={i % 4 === 0 ? 0.85 : 0.4}
                strokeWidth="2"
              />
            );
          })}
        </svg>
      </div>
    );
  }

  if (slug === 'football-montages') {
    return (
      <div className="relative h-full w-full overflow-hidden bg-[#08100d]">
        <div
          className="absolute inset-0"
          style={{
            background:
              'radial-gradient(circle at 68% 25%, rgba(54, 211, 145, 0.28), rgba(16, 18, 26, 0.35) 55%, rgba(9, 10, 15, 0.96) 88%)',
          }}
        />
        <svg
          viewBox={isBanner ? '0 0 1200 480' : '0 0 640 400'}
          preserveAspectRatio="xMidYMid slice"
          className="h-full w-full"
          aria-hidden="true"
        >
          {/* Stadium floodlight beams */}
          <polygon
            points={isBanner ? '220,0 440,0 760,480 420,480' : '110,0 240,0 420,400 220,400'}
            fill="#36d391"
            fillOpacity="0.06"
          />
          <polygon
            points={isBanner ? '860,0 1020,0 700,480 510,480' : '450,0 560,0 380,400 260,400'}
            fill="#cfd8ff"
            fillOpacity="0.05"
          />
          {/* Pitch center circle & touchlines */}
          <line
            x1="0"
            y1={isBanner ? 330 : 275}
            x2={isBanner ? 1200 : 640}
            y2={isBanner ? 330 : 275}
            stroke="#36d391"
            strokeOpacity="0.35"
            strokeWidth="1.5"
          />
          <ellipse
            cx={isBanner ? 600 : 320}
            cy={isBanner ? 330 : 275}
            rx={isBanner ? 190 : 115}
            ry={isBanner ? 52 : 34}
            fill="none"
            stroke="#36d391"
            strokeOpacity="0.48"
            strokeWidth="1.5"
          />
          {/* Curved strike trajectory */}
          <path
            d={
              isBanner
                ? 'M 180 390 Q 560 80 980 185'
                : 'M 80 325 Q 305 65 530 148'
            }
            fill="none"
            stroke="#36d391"
            strokeWidth="2.5"
            strokeDasharray="8 6"
          />
          <circle
            cx={isBanner ? 980 : 530}
            cy={isBanner ? 185 : 148}
            r="9"
            fill="#36d391"
          />
          <circle
            cx={isBanner ? 980 : 530}
            cy={isBanner ? 185 : 148}
            r="24"
            fill="none"
            stroke="#36d391"
            strokeOpacity="0.45"
            strokeWidth="1"
          />
        </svg>
      </div>
    );
  }

  if (slug === 'gaming-content') {
    return (
      <div className="relative h-full w-full overflow-hidden bg-[#080d16]">
        <div
          className="absolute inset-0"
          style={{
            background:
              'radial-gradient(circle at 60% 42%, rgba(79, 176, 255, 0.28), rgba(16, 18, 26, 0.4) 55%, rgba(9, 10, 15, 0.96) 90%)',
          }}
        />
        <svg
          viewBox={isBanner ? '0 0 1200 480' : '0 0 640 400'}
          preserveAspectRatio="xMidYMid slice"
          className="h-full w-full"
          aria-hidden="true"
        >
          {/* Perspective horizon grid */}
          {Array.from({ length: 9 }).map((_, i) => {
            const y = (isBanner ? 250 : 210) + i * (isBanner ? 28 : 24);
            return (
              <line
                key={`h-${i}`}
                x1="0"
                y1={y}
                x2={isBanner ? 1200 : 640}
                y2={y}
                stroke="#4fb0ff"
                strokeOpacity={0.14 + i * 0.025}
                strokeWidth="1"
              />
            );
          })}
          {/* Precision reticle */}
          <circle
            cx={isBanner ? 600 : 320}
            cy={isBanner ? 210 : 175}
            r={isBanner ? 105 : 74}
            fill="none"
            stroke="#4fb0ff"
            strokeOpacity="0.55"
            strokeWidth="1.5"
          />
          <circle
            cx={isBanner ? 600 : 320}
            cy={isBanner ? 210 : 175}
            r={isBanner ? 42 : 30}
            fill="none"
            stroke="#cfd8ff"
            strokeOpacity="0.7"
            strokeWidth="1"
          />
          {/* Crosshair ticks */}
          <line
            x1={isBanner ? 460 : 215}
            y1={isBanner ? 210 : 175}
            x2={isBanner ? 535 : 270}
            y2={isBanner ? 210 : 175}
            stroke="#4fb0ff"
            strokeWidth="2"
          />
          <line
            x1={isBanner ? 665 : 370}
            y1={isBanner ? 210 : 175}
            x2={isBanner ? 740 : 425}
            y2={isBanner ? 210 : 175}
            stroke="#4fb0ff"
            strokeWidth="2"
          />
          <line
            x1={isBanner ? 600 : 320}
            y1={isBanner ? 75 : 70}
            x2={isBanner ? 600 : 320}
            y2={isBanner ? 145 : 125}
            stroke="#4fb0ff"
            strokeWidth="2"
          />
          <line
            x1={isBanner ? 600 : 320}
            y1={isBanner ? 275 : 225}
            x2={isBanner ? 600 : 320}
            y2={isBanner ? 345 : 280}
            stroke="#4fb0ff"
            strokeWidth="2"
          />
        </svg>
      </div>
    );
  }

  // live-streams
  return (
    <div className="relative h-full w-full overflow-hidden bg-[#140910]">
      <div
        className="absolute inset-0"
        style={{
          background:
            'radial-gradient(circle at 65% 35%, rgba(255, 107, 138, 0.3), rgba(116, 130, 255, 0.08) 52%, rgba(9, 10, 15, 0.96) 88%)',
        }}
      />
      <svg
        viewBox={isBanner ? '0 0 1200 480' : '0 0 640 400'}
        preserveAspectRatio="xMidYMid slice"
        className="h-full w-full"
        aria-hidden="true"
      >
        {/* Concentric broadcast wave arcs */}
        {[70, 120, 175, 235].map((r, idx) => (
          <circle
            key={r}
            cx={isBanner ? 760 : 410}
            cy={isBanner ? 215 : 175}
            r={isBanner ? r * 1.2 : r * 0.85}
            fill="none"
            stroke="#ff6b8a"
            strokeOpacity={0.55 - idx * 0.11}
            strokeWidth="1.5"
          />
        ))}
        {/* Mobile portrait stage frame */}
        <rect
          x={isBanner ? 240 : 120}
          y={isBanner ? 76 : 64}
          width={isBanner ? 184 : 150}
          height={isBanner ? 328 : 268}
          fill="#090a0f"
          fillOpacity="0.6"
          stroke="#ff6b8a"
          strokeOpacity="0.7"
          strokeWidth="1.5"
        />
        {/* Live audio waveform bars */}
        {Array.from({ length: 24 }).map((_, i) => {
          const x = (isBanner ? 490 : 300) + i * (isBanner ? 24 : 12);
          const amp = 14 + Math.abs(Math.sin(i * 0.72)) * (isBanner ? 74 : 52);
          const cy = isBanner ? 240 : 200;
          return (
            <line
              key={i}
              x1={x}
              y1={cy - amp / 2}
              x2={x}
              y2={cy + amp / 2}
              stroke={i % 3 === 0 ? '#cfd8ff' : '#ff6b8a'}
              strokeOpacity="0.82"
              strokeWidth={isBanner ? 3 : 2}
            />
          );
        })}
      </svg>
    </div>
  );
}

export function ProjectArtwork({ slug, variant = 'card', alt }: ProjectArtworkProps) {
  const [failedSlug, setFailedSlug] = useState<CategorySlug | null>(null);
  const isBanner = variant === 'banner';
  const coverSrc = TOPIC_COVER_IMAGES[slug];
  const imageFailed = failedSlug === slug;

  return (
    <div className="relative h-full w-full overflow-hidden bg-[#090a0f]">
      {/* Resilient procedural fallback stays underneath */}
      <ProceduralFallback slug={slug} isBanner={isBanner} />

      {/* Bespoke generated topic artwork */}
      {coverSrc && !imageFailed && (
        <img
          src={coverSrc}
          alt={alt ?? `${slug.replace('-', ' ')} showcase artwork`}
          loading={isBanner ? 'eager' : 'lazy'}
          referrerPolicy="no-referrer"
          onError={() => setFailedSlug(slug)}
          className="absolute inset-0 h-full w-full object-cover"
        />
      )}

      {/* Subtle nocturnal edge-blending scrim */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#090a0f]/75 via-[#090a0f]/15 to-[#090a0f]/30"
      />
    </div>
  );
}

