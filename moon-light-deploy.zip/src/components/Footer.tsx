import { ArrowUp } from 'lucide-react';
import { SITE_IDENTITY, SOCIAL_LINKS } from '../data/portfolioData';

interface FooterProps {
  onBackToTop: () => void;
}

export function Footer({ onBackToTop }: FooterProps) {
  return (
    <footer className="bg-[#090a0f] pb-20 pt-10 sm:py-12">
      <div className="mx-auto flex max-w-6xl flex-col gap-8 px-4 sm:flex-row sm:items-center sm:justify-between sm:px-6 lg:px-8">
        <p className="font-mono-label text-xs uppercase tracking-[0.18em] text-[#9298b0]">
          {SITE_IDENTITY.copyright}
        </p>

        <div className="flex flex-wrap items-center gap-6">
          {SOCIAL_LINKS.filter((s) => Boolean(s.url)).map((s) => (
            <a
              key={s.id}
              href={s.url!}
              target="_blank"
              rel="noopener noreferrer"
              className="font-mono-label text-xs uppercase tracking-[0.16em] text-[#9298b0] transition-colors hover:text-[#e9ecf8]"
            >
              {s.platform}
            </a>
          ))}

          <button
            type="button"
            onClick={onBackToTop}
            className="inline-flex min-h-[44px] items-center gap-2 border border-[#20233a] bg-[#10121a] px-4 py-2 font-mono-label text-xs uppercase tracking-[0.16em] text-[#cfd8ff] transition-colors hover:border-[#7482ff] hover:text-[#e9ecf8]"
          >
            <span>Back to top</span>
            <ArrowUp className="h-3.5 w-3.5" aria-hidden="true" />
          </button>
        </div>
      </div>
    </footer>
  );
}
