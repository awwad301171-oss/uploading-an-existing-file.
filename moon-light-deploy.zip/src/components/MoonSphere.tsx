import { useEffect, useRef } from 'react';
import { clampParallax } from '../utils/moonMath';

interface MoonSphereProps {
  reducedMotion: boolean;
  mouseOffset: { nx: number; ny: number };
}

interface Crater {
  x: number;
  y: number;
  r: number;
  depth: number;
}

const LUNAR_CRATERS: Crater[] = [
  { x: 0.34, y: 0.32, r: 0.085, depth: 0.16 },
  { x: 0.62, y: 0.28, r: 0.065, depth: 0.14 },
  { x: 0.48, y: 0.56, r: 0.11, depth: 0.17 },
  { x: 0.28, y: 0.62, r: 0.055, depth: 0.12 },
  { x: 0.68, y: 0.63, r: 0.078, depth: 0.15 },
  { x: 0.42, y: 0.21, r: 0.04, depth: 0.11 },
  { x: 0.56, y: 0.41, r: 0.045, depth: 0.13 },
  { x: 0.22, y: 0.45, r: 0.048, depth: 0.13 },
  { x: 0.73, y: 0.45, r: 0.036, depth: 0.11 },
  { x: 0.51, y: 0.77, r: 0.052, depth: 0.12 },
  { x: 0.38, y: 0.72, r: 0.032, depth: 0.1 },
];

export function MoonSphere({ reducedMotion, mouseOffset }: MoonSphereProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const size = 512;
    canvas.width = size;
    canvas.height = size;

    const cx = size / 2;
    const cy = size / 2;
    const radius = size * 0.46;

    ctx.clearRect(0, 0, size, size);

    ctx.save();
    ctx.beginPath();
    ctx.arc(cx, cy, radius, 0, Math.PI * 2);
    ctx.clip();

    // Base lunar sphere illumination gradient
    const baseGrad = ctx.createRadialGradient(
      cx - radius * 0.32,
      cy - radius * 0.32,
      radius * 0.08,
      cx + radius * 0.18,
      cy + radius * 0.18,
      radius * 1.15
    );
    baseGrad.addColorStop(0, '#f3f6ff');
    baseGrad.addColorStop(0.32, '#cfd8ff');
    baseGrad.addColorStop(0.68, '#7783ad');
    baseGrad.addColorStop(0.92, '#2b324e');
    baseGrad.addColorStop(1, '#101322');
    ctx.fillStyle = baseGrad;
    ctx.fillRect(0, 0, size, size);

    // Subtle dark lunar maria (seas)
    const maria = [
      { x: 0.36, y: 0.38, rx: 0.2, ry: 0.14, rot: -0.4, alpha: 0.16 },
      { x: 0.58, y: 0.36, rx: 0.16, ry: 0.19, rot: 0.3, alpha: 0.14 },
      { x: 0.45, y: 0.62, rx: 0.22, ry: 0.13, rot: 0.15, alpha: 0.12 },
      { x: 0.66, y: 0.58, rx: 0.12, ry: 0.15, rot: -0.2, alpha: 0.15 },
    ];
    for (const mare of maria) {
      ctx.save();
      ctx.translate(mare.x * size, mare.y * size);
      ctx.rotate(mare.rot);
      const mGrad = ctx.createRadialGradient(0, 0, 4, 0, 0, mare.rx * size);
      mGrad.addColorStop(0, `rgba(28, 34, 58, ${mare.alpha})`);
      mGrad.addColorStop(1, 'rgba(28, 34, 58, 0)');
      ctx.fillStyle = mGrad;
      ctx.scale(1, mare.ry / mare.rx);
      ctx.beginPath();
      ctx.arc(0, 0, mare.rx * size, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    // Soft craters with directional lunar lighting (upper-left lit)
    for (const c of LUNAR_CRATERS) {
      const px = cx + (c.x - 0.5) * radius * 2;
      const py = cy + (c.y - 0.5) * radius * 2;
      const pr = c.r * radius;

      // Crater shadow cavity
      const craterGrad = ctx.createLinearGradient(
        px - pr,
        py - pr,
        px + pr,
        py + pr
      );
      craterGrad.addColorStop(0, `rgba(22, 27, 46, ${c.depth * 1.4})`);
      craterGrad.addColorStop(0.55, `rgba(92, 103, 142, ${c.depth * 0.4})`);
      craterGrad.addColorStop(1, `rgba(233, 236, 248, ${c.depth * 1.15})`);

      ctx.fillStyle = craterGrad;
      ctx.beginPath();
      ctx.arc(px, py, pr, 0, Math.PI * 2);
      ctx.fill();

      // Subtle rim highlight on opposite inner edge
      ctx.strokeStyle = `rgba(233, 236, 248, ${c.depth * 0.55})`;
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.arc(px, py, pr * 0.96, -0.3, Math.PI * 0.7);
      ctx.stroke();
    }

    // Limb atmospheric rim glow
    const rimGrad = ctx.createRadialGradient(cx, cy, radius * 0.72, cx, cy, radius);
    rimGrad.addColorStop(0, 'rgba(116, 130, 255, 0)');
    rimGrad.addColorStop(0.85, 'rgba(116, 130, 255, 0.12)');
    rimGrad.addColorStop(1, 'rgba(207, 216, 255, 0.35)');
    ctx.fillStyle = rimGrad;
    ctx.fillRect(0, 0, size, size);

    ctx.restore();
  }, []);

  const parallax = reducedMotion
    ? { x: 0, y: 0 }
    : clampParallax(mouseOffset.nx, mouseOffset.ny, 20);

  return (
    <div
      className="relative flex items-center justify-center select-none"
      style={{
        transform: `translate3d(${parallax.x}px, ${parallax.y}px, 0)`,
        transition: reducedMotion ? 'none' : 'transform 280ms cubic-bezier(0.16, 1, 0.3, 1)',
      }}
    >
      {/* Blue lunar halo */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -inset-10 rounded-full bg-[radial-gradient(circle,rgba(116,130,255,0.28)_0%,rgba(207,216,255,0.08)_46%,rgba(9,10,15,0)_72%)] blur-2xl"
      />

      {/* Orbital hairline ring */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -inset-6 rounded-full border border-[#cfd8ff]/12"
      />

      {/* Floating Moon Canvas */}
      <div className={reducedMotion ? '' : 'animate-moon-float'}>
        <canvas
          ref={canvasRef}
          data-testid="hero-moon-canvas"
          aria-label="Glowing moon illustration with soft lunar craters"
          role="img"
          className="h-56 w-56 sm:h-72 sm:w-72 md:h-80 md:w-80 lg:h-[360px] lg:w-[360px] rounded-full shadow-[0_0_65px_rgba(116,130,255,0.28)]"
        />
      </div>
    </div>
  );
}
