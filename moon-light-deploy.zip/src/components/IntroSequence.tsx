import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';

interface IntroSequenceProps {
  skipImmediately: boolean;
  onComplete: () => void;
}

const WORDMARK_CHARS = ['M', 'O', 'O', 'N', ' ', 'L', 'I', 'G', 'H', 'T'];

export function IntroSequence({ skipImmediately, onComplete }: IntroSequenceProps) {
  const [visible, setVisible] = useState(!skipImmediately);

  useEffect(() => {
    if (skipImmediately) {
      setVisible(false);
      onComplete();
      return;
    }

    const timer = window.setTimeout(() => {
      setVisible(false);
      onComplete();
    }, 2250);

    return () => window.clearTimeout(timer);
  }, [skipImmediately, onComplete]);

  const handleSkip = () => {
    setVisible(false);
    onComplete();
  };

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          data-testid="intro-sequence"
          initial={{ opacity: 1 }}
          exit={{ opacity: 0, transition: { duration: 0.45, ease: [0.16, 1, 0.3, 1] } }}
          className="fixed inset-0 z-[60] flex flex-col items-center justify-center bg-[#090a0f] select-none"
          aria-label="Opening sequence"
        >
          {/* Tiny point of light expanding into a glowing moon */}
          <div className="relative flex flex-col items-center justify-center">
            <motion.div
              initial={{ scale: 0.04, opacity: 0.9 }}
              animate={{ scale: [0.04, 1.05, 1], opacity: [0.9, 1, 0.95] }}
              transition={{ duration: 1.05, ease: [0.16, 1, 0.3, 1] }}
              className="relative h-24 w-24 rounded-full bg-[radial-gradient(circle_at_35%_35%,#f4f7ff_0%,#cfd8ff_38%,#6d79a8_78%,#1e243c_100%)] shadow-[0_0_55px_rgba(116,130,255,0.45),0_0_110px_rgba(207,216,255,0.22)]"
            />

            {/* Letter-by-letter MOON LIGHT wordmark */}
            <div className="mt-8 flex items-center justify-center gap-[0.18em] font-display text-xl sm:text-2xl font-bold tracking-[0.22em] text-[#e9ecf8]">
              {WORDMARK_CHARS.map((char, index) => (
                <motion.span
                  key={`${char}-${index}`}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{
                    delay: 0.65 + index * 0.075,
                    duration: 0.35,
                    ease: [0.16, 1, 0.3, 1],
                  }}
                  className={char === ' ' ? 'w-3' : 'inline-block'}
                >
                  {char === ' ' ? '\u00A0' : char}
                </motion.span>
              ))}
            </div>
          </div>

          <button
            type="button"
            onClick={handleSkip}
            className="mt-12 min-h-[44px] border border-[#20233a] bg-[#10121a]/80 px-5 py-2 font-mono-label text-xs uppercase tracking-[0.2em] text-[#9298b0] transition-colors hover:border-[#7482ff] hover:text-[#e9ecf8]"
          >
            Skip intro
          </button>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
