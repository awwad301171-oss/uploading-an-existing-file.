import { useEffect, useRef, useState } from 'react';

interface CustomCursorProps {
  disabled: boolean;
}

export function CustomCursor({ disabled }: CustomCursorProps) {
  const dotRef = useRef<HTMLDivElement | null>(null);
  const ringRef = useRef<HTMLDivElement | null>(null);
  const [visible, setVisible] = useState(false);
  const [expanded, setExpanded] = useState(false);

  useEffect(() => {
    if (disabled) {
      document.body.classList.remove('custom-cursor-active');
      return;
    }

    document.body.classList.add('custom-cursor-active');

    let targetX = -100;
    let targetY = -100;
    let ringX = -100;
    let ringY = -100;
    let rafId = 0;

    const tick = () => {
      const dx = targetX - ringX;
      const dy = targetY - ringY;
      ringX += dx * 0.22;
      ringY += dy * 0.22;
      if (ringRef.current) {
        ringRef.current.style.transform = `translate3d(${ringX}px, ${ringY}px, 0)`;
      }
      if (Math.abs(dx) > 0.25 || Math.abs(dy) > 0.25) {
        rafId = window.requestAnimationFrame(tick);
      } else {
        ringX = targetX;
        ringY = targetY;
        if (ringRef.current) {
          ringRef.current.style.transform = `translate3d(${ringX}px, ${ringY}px, 0)`;
        }
        rafId = 0;
      }
    };

    const scheduleTick = () => {
      if (!rafId) {
        rafId = window.requestAnimationFrame(tick);
      }
    };

    const onMove = (e: MouseEvent) => {
      targetX = e.clientX;
      targetY = e.clientY;
      if (!visible) {
        ringX = targetX;
        ringY = targetY;
        setVisible(true);
      }

      if (dotRef.current) {
        dotRef.current.style.transform = `translate3d(${targetX}px, ${targetY}px, 0)`;
      }
      scheduleTick();

      const target = e.target as HTMLElement | null;
      const isInteractive = Boolean(
        target?.closest('a, button, [role="button"], [data-cursor="expand"]')
      );
      setExpanded(isInteractive);
    };

    const onLeave = () => {
      setVisible(false);
    };

    window.addEventListener('mousemove', onMove, { passive: true });
    document.addEventListener('mouseleave', onLeave);

    return () => {
      document.body.classList.remove('custom-cursor-active');
      window.removeEventListener('mousemove', onMove);
      document.removeEventListener('mouseleave', onLeave);
      if (rafId) window.cancelAnimationFrame(rafId);
    };
  }, [disabled, visible]);

  if (disabled) return null;

  return (
    <div aria-hidden="true" className="pointer-events-none fixed inset-0 z-[70]">
      {/* Inner glowing dot */}
      <div
        ref={dotRef}
        className={`fixed left-0 top-0 -ml-1 -mt-1 h-2 w-2 rounded-full bg-[#cfd8ff] shadow-[0_0_12px_rgba(116,130,255,0.85)] transition-opacity duration-150 ${
          visible ? 'opacity-100' : 'opacity-0'
        }`}
      />
      {/* Trailing expansion ring */}
      <div
        ref={ringRef}
        className={`fixed left-0 top-0 rounded-full border border-[#7482ff]/70 transition-[width,height,margin,opacity,border-color] duration-200 ease-out ${
          visible ? 'opacity-100' : 'opacity-0'
        } ${
          expanded
            ? '-ml-6 -mt-6 h-12 w-12 border-[#cfd8ff] bg-[#7482ff]/10'
            : '-ml-4 -mt-4 h-8 w-8'
        }`}
      />
    </div>
  );
}
