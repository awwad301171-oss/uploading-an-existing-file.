import { useEffect, useRef } from 'react';

interface StarfieldCanvasProps {
  reducedMotion: boolean;
  tabVisible: boolean;
}

interface Star {
  x: number;
  y: number;
  radius: number;
  baseAlpha: number;
  speed: number;
  phase: number;
  color: string;
}

interface ShootingStar {
  x: number;
  y: number;
  vx: number;
  vy: number;
  length: number;
  life: number;
  maxLife: number;
}

const STAR_COLORS = ['#e9ecf8', '#cfd8ff', '#b5c3ff', '#9298b0'];

export function StarfieldCanvas({ reducedMotion, tabVisible }: StarfieldCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let width = 0;
    let height = 0;
    let stars: Star[] = [];
    let shootingStars: ShootingStar[] = [];
    let rafId = 0;
    let lastTime = performance.now();
    let nextMeteorIn = 3200;

    const buildStars = () => {
      const count = Math.min(150, Math.max(75, Math.floor((width * height) / 11000)));
      stars = Array.from({ length: count }, (_, i) => {
        // Deterministic-feeling spread
        const seedA = Math.sin(i * 12.9898) * 43758.5453;
        const seedB = Math.cos(i * 78.233) * 19341.123;
        const rx = seedA - Math.floor(seedA);
        const ry = seedB - Math.floor(seedB);
        return {
          x: rx * width,
          y: ry * height,
          radius: i % 11 === 0 ? 1.65 : i % 3 === 0 ? 1.15 : 0.75,
          baseAlpha: 0.25 + (i % 7) * 0.09,
          speed: 0.4 + (i % 5) * 0.25,
          phase: (i * 0.87) % (Math.PI * 2),
          color: STAR_COLORS[i % STAR_COLORS.length],
        };
      });
    };

    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      width = Math.max(1, rect.width);
      height = Math.max(1, rect.height);
      canvas.width = Math.floor(width * dpr);
      canvas.height = Math.floor(height * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      buildStars();
    };

    const drawStaticOrFrame = (now: number) => {
      const dt = Math.min(64, now - lastTime);
      lastTime = now;

      ctx.clearRect(0, 0, width, height);

      // Subtle night-sky radial nebula tint
      const skyGrad = ctx.createRadialGradient(
        width * 0.72,
        height * 0.35,
        20,
        width * 0.72,
        height * 0.35,
        Math.max(width, height) * 0.65
      );
      skyGrad.addColorStop(0, 'rgba(116, 130, 255, 0.06)');
      skyGrad.addColorStop(0.55, 'rgba(16, 18, 26, 0.02)');
      skyGrad.addColorStop(1, 'rgba(9, 10, 15, 0)');
      ctx.fillStyle = skyGrad;
      ctx.fillRect(0, 0, width, height);

      // Draw twinkling stars
      const t = now * 0.001;
      for (const s of stars) {
        const twinkle = reducedMotion ? 0 : Math.sin(t * s.speed + s.phase) * 0.28;
        const alpha = Math.max(0.12, Math.min(0.95, s.baseAlpha + twinkle));
        ctx.globalAlpha = alpha;
        ctx.fillStyle = s.color;
        ctx.beginPath();
        ctx.arc(s.x, s.y, s.radius, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.globalAlpha = 1;

      if (!reducedMotion && tabVisible) {
        nextMeteorIn -= dt;
        if (nextMeteorIn <= 0) {
          nextMeteorIn = 4200 + Math.random() * 4800;
          const startX = width * (0.2 + Math.random() * 0.7);
          const startY = height * (0.05 + Math.random() * 0.3);
          shootingStars.push({
            x: startX,
            y: startY,
            vx: -0.58 - Math.random() * 0.25,
            vy: 0.32 + Math.random() * 0.16,
            length: 75 + Math.random() * 45,
            life: 0,
            maxLife: 700,
          });
        }

        shootingStars = shootingStars.filter((m) => m.life < m.maxLife);
        for (const m of shootingStars) {
          m.x += m.vx * dt;
          m.y += m.vy * dt;
          m.life += dt;

          const progress = m.life / m.maxLife;
          const opacity = Math.sin(progress * Math.PI) * 0.85;
          const norm = Math.hypot(m.vx, m.vy) || 1;
          const tailX = m.x - (m.vx / norm) * m.length;
          const tailY = m.y - (m.vy / norm) * m.length;

          const grad = ctx.createLinearGradient(m.x, m.y, tailX, tailY);
          grad.addColorStop(0, `rgba(207, 216, 255, ${opacity})`);
          grad.addColorStop(1, 'rgba(116, 130, 255, 0)');

          ctx.strokeStyle = grad;
          ctx.lineWidth = 1.4;
          ctx.beginPath();
          ctx.moveTo(m.x, m.y);
          ctx.lineTo(tailX, tailY);
          ctx.stroke();
        }
      }
    };

    resize();
    window.addEventListener('resize', resize);

    if (reducedMotion || !tabVisible) {
      drawStaticOrFrame(performance.now());
      return () => {
        window.removeEventListener('resize', resize);
      };
    }

    const loop = (now: number) => {
      drawStaticOrFrame(now);
      rafId = window.requestAnimationFrame(loop);
    };
    rafId = window.requestAnimationFrame(loop);

    return () => {
      window.cancelAnimationFrame(rafId);
      window.removeEventListener('resize', resize);
    };
  }, [reducedMotion, tabVisible]);

  return (
    <canvas
      ref={canvasRef}
      data-testid="starfield-canvas"
      aria-hidden="true"
      className="pointer-events-none absolute inset-0 h-full w-full"
    />
  );
}
